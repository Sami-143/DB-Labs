﻿namespace Mid_Term_Project
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.btnReport = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.btnHome = new System.Windows.Forms.Button();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.btnManageStudents = new System.Windows.Forms.Button();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.btnManageCLOs = new System.Windows.Forms.Button();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.btnManageRubrics = new System.Windows.Forms.Button();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.btnMarkEvaluations = new System.Windows.Forms.Button();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.btnManageAssessment = new System.Windows.Forms.Button();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.btnComponent = new System.Windows.Forms.Button();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.BtnMarkEvalluation = new System.Windows.Forms.Button();
            this.leftSide = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.HeaderText = new System.Windows.Forms.Label();
            this.allScreenPanel = new System.Windows.Forms.Panel();
            this.manageEvaluation1 = new Mid_Term_Project.manageEvaluation();
            this.manageAssessmentComponent1 = new Mid_Term_Project.manageAssessmentComponent();
            this.manageAssesment1 = new Mid_Term_Project.manageAssesment();
            this.manageRubricLevel1 = new Mid_Term_Project.manageRubricLevel();
            this.manageRubrics1 = new Mid_Term_Project.manageRubrics();
            this.manageCLOs1 = new Mid_Term_Project.manageCLOs();
            this.manageStudents1 = new Mid_Term_Project.manageStudents();
            this.attendence1 = new Mid_Term_Project.Attendence();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.leftSide.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            this.allScreenPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(232)))), ((int)(((byte)(231)))));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.30131F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 77.69869F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.leftSide, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23.83178F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(904, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(57)))), ((int)(((byte)(86)))));
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel13, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel6, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel7, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel8, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel9, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel11, 0, 7);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 10;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.98901F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.89011F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.89011F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.89011F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.89011F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.89011F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.89011F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.89011F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.89011F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.89011F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(201, 450);
            this.tableLayoutPanel2.TabIndex = 1;
            this.tableLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel2_Paint);
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 1;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel13.Controls.Add(this.btnReport, 0, 0);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(0, 357);
            this.tableLayoutPanel13.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 1;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(201, 44);
            this.tableLayoutPanel13.TabIndex = 16;
            // 
            // btnReport
            // 
            this.btnReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnReport.FlatAppearance.BorderSize = 0;
            this.btnReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnReport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReport.Location = new System.Drawing.Point(0, 0);
            this.btnReport.Margin = new System.Windows.Forms.Padding(0);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(201, 44);
            this.btnReport.TabIndex = 4;
            this.btnReport.Text = "Reports";
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45.30387F));
            this.tableLayoutPanel3.Controls.Add(this.btnHome, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(201, 49);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // btnHome
            // 
            this.btnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.btnHome.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnHome.Image = ((System.Drawing.Image)(resources.GetObject("btnHome.Image")));
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(0, 0);
            this.btnHome.Margin = new System.Windows.Forms.Padding(0);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(201, 49);
            this.btnHome.TabIndex = 0;
            this.btnHome.Text = "Attendence";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.btnManageStudents, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 49);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(201, 44);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // btnManageStudents
            // 
            this.btnManageStudents.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnManageStudents.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnManageStudents.FlatAppearance.BorderSize = 0;
            this.btnManageStudents.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageStudents.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageStudents.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnManageStudents.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnManageStudents.Location = new System.Drawing.Point(0, 0);
            this.btnManageStudents.Margin = new System.Windows.Forms.Padding(0);
            this.btnManageStudents.Name = "btnManageStudents";
            this.btnManageStudents.Size = new System.Drawing.Size(201, 44);
            this.btnManageStudents.TabIndex = 5;
            this.btnManageStudents.Text = "Manage Students";
            this.btnManageStudents.UseVisualStyleBackColor = true;
            this.btnManageStudents.Click += new System.EventHandler(this.btnManageStudents_Click);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.btnManageCLOs, 0, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 93);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(201, 44);
            this.tableLayoutPanel6.TabIndex = 6;
            // 
            // btnManageCLOs
            // 
            this.btnManageCLOs.AutoSize = true;
            this.btnManageCLOs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnManageCLOs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnManageCLOs.FlatAppearance.BorderSize = 0;
            this.btnManageCLOs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageCLOs.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageCLOs.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnManageCLOs.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnManageCLOs.Location = new System.Drawing.Point(0, 0);
            this.btnManageCLOs.Margin = new System.Windows.Forms.Padding(0);
            this.btnManageCLOs.Name = "btnManageCLOs";
            this.btnManageCLOs.Size = new System.Drawing.Size(201, 44);
            this.btnManageCLOs.TabIndex = 1;
            this.btnManageCLOs.Text = "Manage CLOs";
            this.btnManageCLOs.UseVisualStyleBackColor = true;
            this.btnManageCLOs.Click += new System.EventHandler(this.btnManageCLOs_Click);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.btnManageRubrics, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 137);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(201, 44);
            this.tableLayoutPanel5.TabIndex = 7;
            // 
            // btnManageRubrics
            // 
            this.btnManageRubrics.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnManageRubrics.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnManageRubrics.FlatAppearance.BorderSize = 0;
            this.btnManageRubrics.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageRubrics.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageRubrics.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnManageRubrics.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnManageRubrics.Location = new System.Drawing.Point(0, 0);
            this.btnManageRubrics.Margin = new System.Windows.Forms.Padding(0);
            this.btnManageRubrics.Name = "btnManageRubrics";
            this.btnManageRubrics.Size = new System.Drawing.Size(201, 44);
            this.btnManageRubrics.TabIndex = 5;
            this.btnManageRubrics.Text = "Manage Rubrics";
            this.btnManageRubrics.UseVisualStyleBackColor = true;
            this.btnManageRubrics.Click += new System.EventHandler(this.btnManageRubrics_Click);
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Controls.Add(this.btnMarkEvaluations, 0, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(0, 181);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(201, 44);
            this.tableLayoutPanel7.TabIndex = 8;
            // 
            // btnMarkEvaluations
            // 
            this.btnMarkEvaluations.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnMarkEvaluations.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnMarkEvaluations.FlatAppearance.BorderSize = 0;
            this.btnMarkEvaluations.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMarkEvaluations.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMarkEvaluations.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnMarkEvaluations.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMarkEvaluations.Location = new System.Drawing.Point(0, 0);
            this.btnMarkEvaluations.Margin = new System.Windows.Forms.Padding(0);
            this.btnMarkEvaluations.Name = "btnMarkEvaluations";
            this.btnMarkEvaluations.Size = new System.Drawing.Size(201, 44);
            this.btnMarkEvaluations.TabIndex = 4;
            this.btnMarkEvaluations.Text = "Rubrics Levels";
            this.btnMarkEvaluations.UseVisualStyleBackColor = true;
            this.btnMarkEvaluations.Click += new System.EventHandler(this.btnMarkEvaluations_Click);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Controls.Add(this.btnManageAssessment, 0, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(0, 225);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(201, 44);
            this.tableLayoutPanel8.TabIndex = 13;
            // 
            // btnManageAssessment
            // 
            this.btnManageAssessment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnManageAssessment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnManageAssessment.FlatAppearance.BorderSize = 0;
            this.btnManageAssessment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageAssessment.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManageAssessment.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnManageAssessment.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnManageAssessment.Location = new System.Drawing.Point(0, 0);
            this.btnManageAssessment.Margin = new System.Windows.Forms.Padding(0);
            this.btnManageAssessment.Name = "btnManageAssessment";
            this.btnManageAssessment.Size = new System.Drawing.Size(201, 44);
            this.btnManageAssessment.TabIndex = 12;
            this.btnManageAssessment.Text = "Assessments";
            this.btnManageAssessment.UseVisualStyleBackColor = true;
            this.btnManageAssessment.Click += new System.EventHandler(this.btnManageAssessment_Click);
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.Controls.Add(this.btnComponent, 0, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(0, 269);
            this.tableLayoutPanel9.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(201, 44);
            this.tableLayoutPanel9.TabIndex = 11;
            // 
            // btnComponent
            // 
            this.btnComponent.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnComponent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnComponent.FlatAppearance.BorderSize = 0;
            this.btnComponent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnComponent.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComponent.ForeColor = System.Drawing.Color.Gainsboro;
            this.btnComponent.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnComponent.Location = new System.Drawing.Point(0, 0);
            this.btnComponent.Margin = new System.Windows.Forms.Padding(0);
            this.btnComponent.Name = "btnComponent";
            this.btnComponent.Size = new System.Drawing.Size(201, 44);
            this.btnComponent.TabIndex = 4;
            this.btnComponent.Text = "Component ";
            this.btnComponent.UseVisualStyleBackColor = true;
            this.btnComponent.Click += new System.EventHandler(this.btnAssessment_Click);
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.BtnMarkEvalluation, 0, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(0, 313);
            this.tableLayoutPanel11.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(201, 44);
            this.tableLayoutPanel11.TabIndex = 17;
            // 
            // BtnMarkEvalluation
            // 
            this.BtnMarkEvalluation.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BtnMarkEvalluation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnMarkEvalluation.FlatAppearance.BorderSize = 0;
            this.BtnMarkEvalluation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMarkEvalluation.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMarkEvalluation.ForeColor = System.Drawing.Color.Gainsboro;
            this.BtnMarkEvalluation.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnMarkEvalluation.Location = new System.Drawing.Point(0, 0);
            this.BtnMarkEvalluation.Margin = new System.Windows.Forms.Padding(0);
            this.BtnMarkEvalluation.Name = "BtnMarkEvalluation";
            this.BtnMarkEvalluation.Size = new System.Drawing.Size(201, 44);
            this.BtnMarkEvalluation.TabIndex = 4;
            this.BtnMarkEvalluation.Text = "Mark Evaluation";
            this.BtnMarkEvalluation.UseVisualStyleBackColor = true;
            this.BtnMarkEvalluation.Click += new System.EventHandler(this.button1_Click);
            // 
            // leftSide
            // 
            this.leftSide.ColumnCount = 1;
            this.leftSide.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.98684F));
            this.leftSide.Controls.Add(this.panel1, 0, 0);
            this.leftSide.Controls.Add(this.allScreenPanel, 0, 1);
            this.leftSide.Dock = System.Windows.Forms.DockStyle.Fill;
            this.leftSide.Location = new System.Drawing.Point(201, 0);
            this.leftSide.Margin = new System.Windows.Forms.Padding(0);
            this.leftSide.Name = "leftSide";
            this.leftSide.RowCount = 2;
            this.leftSide.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.08204F));
            this.leftSide.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 86.91796F));
            this.leftSide.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.leftSide.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.leftSide.Size = new System.Drawing.Size(703, 450);
            this.leftSide.TabIndex = 2;
            this.leftSide.Paint += new System.Windows.Forms.PaintEventHandler(this.allScreenPanel_Paint);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(57)))), ((int)(((byte)(86)))));
            this.panel1.Controls.Add(this.tableLayoutPanel10);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(703, 58);
            this.panel1.TabIndex = 0;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 3;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 79.40341F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 3.977273F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.47727F));
            this.tableLayoutPanel10.Controls.Add(this.HeaderText, 0, 1);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 3;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.24499F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 72.46377F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.3913F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(703, 58);
            this.tableLayoutPanel10.TabIndex = 0;
            // 
            // HeaderText
            // 
            this.HeaderText.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.HeaderText.AutoSize = true;
            this.HeaderText.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HeaderText.ForeColor = System.Drawing.Color.Gainsboro;
            this.HeaderText.Location = new System.Drawing.Point(3, 5);
            this.HeaderText.Name = "HeaderText";
            this.HeaderText.Size = new System.Drawing.Size(127, 41);
            this.HeaderText.TabIndex = 0;
            this.HeaderText.Text = "Home";
            // 
            // allScreenPanel
            // 
            this.allScreenPanel.Controls.Add(this.attendence1);
            this.allScreenPanel.Controls.Add(this.manageEvaluation1);
            this.allScreenPanel.Controls.Add(this.manageAssessmentComponent1);
            this.allScreenPanel.Controls.Add(this.manageAssesment1);
            this.allScreenPanel.Controls.Add(this.manageRubricLevel1);
            this.allScreenPanel.Controls.Add(this.manageRubrics1);
            this.allScreenPanel.Controls.Add(this.manageCLOs1);
            this.allScreenPanel.Controls.Add(this.manageStudents1);
            this.allScreenPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.allScreenPanel.Location = new System.Drawing.Point(0, 58);
            this.allScreenPanel.Margin = new System.Windows.Forms.Padding(0);
            this.allScreenPanel.Name = "allScreenPanel";
            this.allScreenPanel.Size = new System.Drawing.Size(703, 392);
            this.allScreenPanel.TabIndex = 1;
            // 
            // manageEvaluation1
            // 
            this.manageEvaluation1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.manageEvaluation1.Location = new System.Drawing.Point(0, 0);
            this.manageEvaluation1.Name = "manageEvaluation1";
            this.manageEvaluation1.Size = new System.Drawing.Size(703, 392);
            this.manageEvaluation1.TabIndex = 6;
            // 
            // manageAssessmentComponent1
            // 
            this.manageAssessmentComponent1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.manageAssessmentComponent1.Location = new System.Drawing.Point(0, 0);
            this.manageAssessmentComponent1.Name = "manageAssessmentComponent1";
            this.manageAssessmentComponent1.Size = new System.Drawing.Size(703, 392);
            this.manageAssessmentComponent1.TabIndex = 5;
            // 
            // manageAssesment1
            // 
            this.manageAssesment1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.manageAssesment1.Location = new System.Drawing.Point(0, 0);
            this.manageAssesment1.Name = "manageAssesment1";
            this.manageAssesment1.Size = new System.Drawing.Size(703, 392);
            this.manageAssesment1.TabIndex = 4;
            // 
            // manageRubricLevel1
            // 
            this.manageRubricLevel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(232)))), ((int)(((byte)(231)))));
            this.manageRubricLevel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.manageRubricLevel1.Location = new System.Drawing.Point(0, 0);
            this.manageRubricLevel1.Name = "manageRubricLevel1";
            this.manageRubricLevel1.Size = new System.Drawing.Size(703, 392);
            this.manageRubricLevel1.TabIndex = 3;
            this.manageRubricLevel1.Load += new System.EventHandler(this.manageRubricLevel1_Load);
            // 
            // manageRubrics1
            // 
            this.manageRubrics1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.manageRubrics1.Location = new System.Drawing.Point(0, 0);
            this.manageRubrics1.Margin = new System.Windows.Forms.Padding(0);
            this.manageRubrics1.Name = "manageRubrics1";
            this.manageRubrics1.Size = new System.Drawing.Size(703, 392);
            this.manageRubrics1.TabIndex = 2;
            // 
            // manageCLOs1
            // 
            this.manageCLOs1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.manageCLOs1.Location = new System.Drawing.Point(0, 0);
            this.manageCLOs1.Name = "manageCLOs1";
            this.manageCLOs1.Size = new System.Drawing.Size(703, 392);
            this.manageCLOs1.TabIndex = 1;
            // 
            // manageStudents1
            // 
            this.manageStudents1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(232)))), ((int)(((byte)(231)))));
            this.manageStudents1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.manageStudents1.Location = new System.Drawing.Point(0, 0);
            this.manageStudents1.Name = "manageStudents1";
            this.manageStudents1.Size = new System.Drawing.Size(703, 392);
            this.manageStudents1.TabIndex = 0;
            // 
            // attendence1
            // 
            this.attendence1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.attendence1.Location = new System.Drawing.Point(0, 0);
            this.attendence1.Name = "attendence1";
            this.attendence1.Size = new System.Drawing.Size(703, 392);
            this.attendence1.TabIndex = 7;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.MaximumSizeChanged += new System.EventHandler(this.Home_MaximumSizeChanged);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.leftSide.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.allScreenPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Button btnComponent;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Button btnManageStudents;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Button btnManageCLOs;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Button btnManageRubrics;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Button btnMarkEvaluations;
        private System.Windows.Forms.TableLayoutPanel leftSide;
        private System.Windows.Forms.Panel allScreenPanel;
        private manageCLOs manageCLOs1;
        private manageStudents manageStudents1;
        private manageRubrics manageRubrics1;
        private manageRubricLevel manageRubricLevel1;
        private System.Windows.Forms.Label HeaderText;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Button btnManageAssessment;
        private manageAssesment manageAssesment1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private manageAssessmentComponent manageAssessmentComponent1;
        private manageEvaluation manageEvaluation1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Button BtnMarkEvalluation;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private Attendence attendence1;
        //private manageAssessmentComponent manageAssessmentComponent1;
    }
}

