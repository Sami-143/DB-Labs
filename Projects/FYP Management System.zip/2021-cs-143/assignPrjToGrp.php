<?php
include 'header.php'; 
include 'dbSQL.php';
?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Assign Project to Group</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Assign Project
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<section class="contact-section">
    <div class="container">
        <div class="row" style="margin: auto">
            <div class="col-md-8" style="margin: auto">
                <div class="contact-form" style="margin: auto">
                    <h4>Assign Project </h4>
                    <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                    <form action="grpAction.php" method="post" class="row">
                        <div class="col-md-6">
                            <Label>Project Title</Label> <br>
                            <?php
                                $query =
                                    "SELECT 
                                    p.Id AS ProjectId,
                                    p.Title AS ProjectTitle
                                FROM 
                                    Project p
                                    LEFT JOIN GroupProject gp ON p.Id = gp.ProjectId
                                WHERE
                                    gp.GroupId IS NULL;
                                ";
                                $res = db::getRecords($query);
                                $groupDropdown =
                                    '<select name="prjId" required>';
                                foreach ($res as $grpRow) {
                                    $groupDropdown .=
                                        '<option value="' .
                                        $grpRow['ProjectId'] .
                                        '">' .
                                        $grpRow['ProjectTitle'] .
                                        '</option>';
                                }
                                $groupDropdown .= '</select>';
                                echo $groupDropdown;
                            ?>
                        </div>
                        <div class="col-md-6">
                            <Label>Group Id</Label> <br>
                            <?php
                                $query =
                                    "SELECT 
                                    g.Id AS GroupId
                                FROM 
                                    [Group] g
                                    LEFT JOIN GroupProject gp ON g.Id = gp.GroupId
                                WHERE 
                                    gp.ProjectId IS NULL";
                                $res = db::getRecords($query);
                                $groupDropdown =
                                    '<select name="grpId" required>';
                                foreach ($res as $grpRow) {
                                    $groupDropdown .=
                                        '<option value="' .
                                        $grpRow['GroupId'] .
                                        '">' .
                                        $grpRow['GroupId'] .
                                        '</option>';
                                }
                                $groupDropdown .= '</select>';
                                echo $groupDropdown;
                            ?>
                        </div>
                        <div class="col-md-6 text-right" style="margin-top: 10px; margin-left: 60px">
                            <input type="submit" name="assignProjSubmit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php';
?>