<?php
    include('header.php');
    include('dbSQL.php');
?>
<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Students Group</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Students Group
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->
<table class="container table table-light table-striped" style="margin-top:40px">
    <?php
$query = "SELECT g.Id as GroupId, g.Created_On, s.Id as StudentId, s.RegistrationNo, gs.Status, gs.AssignmentDate 
          FROM [Group] g 
          JOIN GroupStudent gs ON g.Id = gs.GroupId 
          JOIN Student s ON gs.StudentId = s.Id 
          ORDER BY g.Created_On ASC";

$res = db::getRecords($query);

$lastGroupId = -1;
$section = '';
foreach ($res as $row) {
    if ($lastGroupId !== $row['GroupId']) {
        // Display new group row
        if ($lastGroupId !== -1) {
            $section .= '        </tbody>';
            $section .= '    </table>';
            $section .= '</div>';
            echo $section;
        }
        $lastGroupId = $row['GroupId'];
        $section = '<div>';
        $section .= '    <h2 style = "font-size:20px ; font-weight: 600; margin-left: 320px; margin-top: 20px">Group ID: ' . $row['GroupId'] . '</h2>';
        $section .= '    <table class="container table table-light table-striped" style="margin-top:40px">';
        $section .= '        <thead>';
        $section .= '            <tr>';
        $section .= '                <th>Student ID</th>';
        $section .= '                <th>Registration Number</th>';
        $section .= '                <th>Status</th>' ;
        $section .= '                <th>Assignment Date</th>';
        $section .= '            </tr>';
        $section .= '        </thead>';
        $section .= '        <tbody>';
    }
    
    // Display student row
    $section .= '            <tr>';
    $section .= '                <td>' . $row['StudentId'] . '</td>';
    $section .= '                <td>' . $row['RegistrationNo'] . '</td>';
    $section .= '                <td>' . $row['Status'] . '</td>';
    $assignmentDate = date('d-m-Y', strtotime($row['AssignmentDate']));
    $section .= '                <td>' . $assignmentDate . '</td>';
    $section .= '            </tr>';
}

// Display final group row
if ($lastGroupId !== -1) {
    $section .= '        </tbody>';
    $section .= '    </table>';
    $section .= '</div>';
    echo $section;
}
?>


</table>
<a href="javascript:window.print();" class="bisylms-btn" style="margin-left:800px; margin-bottom:100px">Print</a>

<?php
    // include('footer.php');
?>