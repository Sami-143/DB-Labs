<?php
include 'header.php';
include 'dbSQL.php';
?>

<!-- Banner Start -->
   <section class="page-banner" style="background-image: url(assets/images/banner3.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="banner-title">Courses Grid</h2>
                        <div class="bread-crumbs">
                            <a href="index.html">Home</a> <span></span> Courses Grid
                        </div>
                    </div>
                </div>
            </div>
    </section>  
        <!-- Banner End -->
    <?php
    $query = 'SELECT * FROM Project';
    $res = db::getRecords($query);
    // foreach ($res as $row) {
        ?>
        <section class="feature-course-section">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <h2 class="sec-title"><span>Featured </span>Projects</h2>
                </div>
                <div class="col-md-7">
                    <ul class="shaf-filter">
                        <li class="active" data-group="all">All</li>
                        <li data-group="development">Web Development</li>
                        <li data-group="architecture">Architecture</li>
                        <li data-group="engineering">Engineering</li>
                        <li data-group="science">Data Science</li>
                    </ul>
                </div>
            </div>
            <?php 
                $temp = '<div class="row shafull-container"> ';
                $temp .= '<div class="col-lg-4 col-md-6 shaf-item">';
                $temp .= '    <div class="feature-course-item">';
                $temp .= '        <div class="flipper">';
                $temp .= '            <div class="front">';
                $temp .= '                <div class="fcf-thumb">';
                $temp.= '                    <img src="assets/images/home/course/1.png" alt="">';
                $temp .= '                </div>';
                $temp .= '                <p>Computer Science</p>';
                $temp .= '                <h4>Using Creative Problem Solving</h4>';
                $temp .= '                <div class="fcf-bottom">';
                $temp .= '                    <a href="#"><i class="icon_book_alt"></i>10 Lessons</a>';
                $temp .= '                    <a href="#"><i class="icon_profile"></i>142</a>';
                $temp .= '                </div>';
                $temp .= '            </div>';
                $temp .= '            <div class="back">';
                $temp .= '                <div class="fcf-thumb">';
                $temp .= '                    <img src="assets/images/home/course/1.png" alt="">';
                $temp .= '                </div>';
                $temp .= '                <a href="#" class="c-cate">Computer Science</a>';
                $temp .= '                <h4><a href="#">Using Creative Problem Solving</a></h4>';
                $temp .= '                <div class="ratings">';
                $temp .= '                    <i class="icon_star"></i>';
                $temp .= '                    <i class="icon_star"></i>';
                $temp .= '                    <i class="icon_star"></i>';
                $temp .= '                    <i class="icon_star"></i>';
                $temp .= '                    <i class="icon_star"></i>';
                $temp .= '                    <span>4.5 (1 Reviews)</span>';
                $temp .= '                </div>';
                $temp .= '                <div class="course-price">';
                $temp .= '                    $38.00';
                $temp .= '                    <span>$50.00</span>';
                $temp .= '                </div>';
                $temp .= '                <div class="author">';
                $temp .= '                    <img src="assets/images/home/course/author.png" alt="">';
                $temp .= '                    <a href="#">Anthony</a>';
                $temp .= '                </div>';
                $temp .= '                <div class="fcf-bottom">';
                $temp .= '                    <a href="#"><i class="icon_book_alt"></i>10 Lessons</a>';
                $temp .= '                    <a href="#"><i class="icon_profile"></i>142</a>';
                $temp .= '                </div>';
                $temp .= '            </div>';
                $temp .= '        </div>';
                $temp .= '    </div>';
            echo $temp;
            ?>
            </div>
            </div>
            </div>
            </section>
                            <!-- <div class="tab-pane fade in" id="list" role="tabpanel">

                                <div class="course-item-3 ci-3-color">
                                    <div class="ci-thumb">
                                        <img src="assets/images/home3/p1.jpg" alt="">
                                        <a href="#" class="c-cate">Software</a>
                                    </div>
                                    <div class="course-details">
                                        <img class="line-bg" src="assets/images/home3/line.jpg" alt="">
                                        <div class="fcf-bottom">
                                            <a href="#"><i class="icon_book_alt"></i>14 Lessons</a>
                                            <a href="#"><i class="icon_profile"></i>203</a>
                                        </div>
                                        <h4><a href="#">The Art of Black and White Photography</a></h4>
                                        <p>
                                            Discover how to become a successful Project Manager with this free online introductory course.
                                        </p>
                                        <div class="author">
                                            <img src="assets/images/home3/author.png" alt="">
                                            <a href="#">Anthony</a>
                                        </div>
                                        <div class="price-rate">
                                            <div class="course-price">
                                                $42.76
                                                <span>$250.85</span>
                                            </div>
                                            <div class="ratings">
                                                <i class="icon_star"></i>
                                                <i class="icon_star"></i>
                                                <i class="icon_star"></i>
                                                <i class="icon_star"></i>
                                                <i class="icon_star"></i>
                                                <span>4.5 (2 Reviews)</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                // <!-- Pagination -->
                                <!-- <div class="row">
                                    <div class="col-lg-12">
                                        <div class="bisylms-pagination">
                                            <span class="current">01</span>
                                            <a href="#">02</a>
                                            <a class="next" href="#">next<i class="arrow_right"></i></a>
                                        </div>
                                    </div>
                                </div> -->
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php include 'footer.php';

?>
