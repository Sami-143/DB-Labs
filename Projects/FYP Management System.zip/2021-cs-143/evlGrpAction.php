<?php
include 'dbSQL.php';
if (isset($_POST['evlGrpSubmit'])) {
    $obtMarks = $_POST['obtMarks'];
    $grpId = $_POST['grpId'];
    $evlId = $_POST['evlId'];
    $date = date('Y-m-d');
    //validations
    $sql = "SELECT * FROM GroupEvaluation WHERE GroupId = $grpId and EvaluationId = $evlId";
    $result = db::getRecords($sql);
    if (count($result) > 0) {
        echo '<script>alert("Group already evaluated for this evaluation.");</script>';
        return;
    }
    $sql = "SELECT * FROM GroupEvaluation WHERE GroupId = $grpId";
    $result = db::getRecords($sql);
    if (count($result) > 0) {
        echo '<script>alert("Group already evaluated.");</script>';
        return;
    }
    $sql = "INSERT INTO GroupEvaluation (GroupId, EvaluationId, ObtainedMarks, EvaluationDate) VALUES ($grpId, $evlId, $obtMarks, '$date')";
    $rowCount = db::insertRecords($sql);
    if ($rowCount > 0) {
        echo '<script>alert("Record Inserted successfully.");</script>';
    } else {
        echo '<script>alert("Error in Insertion");</script>';
    }
    return;
}
if (isset($_POST['advDelSubmit'])) {
    $fName = $_POST['f-name'];
    $designation = $_POST['designation'];

    $sql = "SELECT Person.Id FROM Advisor Cross Join Person WHERE Advisor.Id = Person.Id and FirstName = '$fName' and Designation = '$designation'";
    $id = db::getRecords($sql);
    if (count($id) == 0) {
    echo '<script>alert("Advisor does not exist.");</script>';
    return;
    }
    $id = $id[0]['Id'];

    // delete corresponding records from the ProjectAdvisor table first
    $sql = "DELETE FROM ProjectAdvisor WHERE AdvisorId = $id";
    $rowCount = db::deleteRecords($sql);

    // delete record from the Advisor table
    $sql = "DELETE FROM Advisor WHERE Advisor.Id = $id";
    $rowCount = db::deleteRecords($sql);

    // delete record from the Person table
    $sql = "DELETE FROM Person WHERE Person.Id = $id";
    $rowCount = db::deleteRecords($sql);

    if ($rowCount > 0) {
        echo '<script>alert("Record Deleted successfully.");</script>';
    } else {
        echo '<script>alert("Error in Deleting");</script>';
    }
    return;
}
if (isset($_POST['stuSearchSubmit'])) {
    $regNum = $_POST['regNum'];
    $fName = $_POST['f-name'];
    $sql = "SELECT * FROM Person WHERE Id = (SELECT Id FROM Student WHERE RegistrationNo = '$regNum') and FirstName = '$fName'";
    $result = db::getRecords($sql);
    if (count($result) > 0) {
    ?>
<?php
include 'header.php'; ?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Search Advisor</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Search Advisor
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<section class="contact-section">
    <div class="container">
        <div class="row" style="margin: auto">
            <div class="col-md-8" style="margin: auto">
                <div class="contact-form" style="margin: auto">
                    <h4>Search Advisor</h4>
                    <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                    <form action="advAction.php" method="post" class="row">
                        <div class="col-md-6">
                            <input type="text" name="f-name" placeholder="First Name" required>
                        </div>
                        <div class="col-md-6">
                            <Label>Designation</Label> <br>
                            <?php
                                        $query =
                                            "SELECT * FROM Lookup where Category = 'Designation'";
                                        $res = db::getRecords($query);
                                        $designationDropdown =
                                            '<select name="designation">';

                                        foreach ($res as $des) {
                                            $designationDropdown .=
                                                '<option value="' .
                                                $des['Id'] .
                                                '">' .
                                                $des['Value'] .
                                                '</option>';
                                        }
                                        $designationDropdown .= '</select>';
                                        echo $designationDropdown;
                                        ?>
                        </div>
                        <div class="col-md-6 text-right" style="margin-left: 70px">
                            <input type="submit" name="advDelSubmit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>
<?php
    } else {
        echo '<script>alert("Record Not Found.");</script>';
    }
}
?>