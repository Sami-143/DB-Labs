<?php
    include('header.php');
    include('dbSQL.php');
?>
<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Top 10 Groups</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Top 10 Groups
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->
<table class="container table table-light table-striped" style="margin-top:40px">
    <?php
        $query = "SELECT TOP 10
        g.Id AS GroupId,
        SUM(ge.ObtainedMarks) AS TotalObtainedMarks,EvaluationDate
    FROM
        [Group] g
        INNER JOIN GroupEvaluation ge ON g.Id = ge.GroupId
    GROUP BY
        g.Id, EvaluationDate
    ORDER BY
        TotalObtainedMarks DESC
    ";
        $res = db::getRecords($query);   
        $section = "<thead>";
        $section .= "<tr>";
        $section .= '    <th scope="col">Sr.</th>';
        $section .= '    <th scope="col">Group Id</th>';
        $section .= '    <th scope="col">Obtained Marks</th>';
        $section .= '    <th scope="col">Evaluation Date</th>';
        $section .= '</tr>';
        $section .= '</thead>';
        $count = 1;
        echo $section;
        foreach($res as $row)
        {
            $evlDate = " ";
            $evlDate = date('d-m-Y', strtotime($row['EvaluationDate']));
            $section = "<tbody>";
            $section .= "<tr>";
            $section .= '    <th scope="row">'.$count.'</th>';
            $section .= '    <td>'.$row['GroupId'].'</td>';
            $section .= '    <td>'.$row['TotalObtainedMarks'].'</td>';
            $section .= '    <td>'. $evlDate .'</td>';
            $section .= '</tr>';
            $section .= '</tbody>';
            echo $section;
            $count++;
        }
    ?>

</table>
<a href="javascript:window.print();" class="bisylms-btn" style="margin-left:800px; margin-bottom:100px">Print</a>

<?php
    // include('footer.php');
?>