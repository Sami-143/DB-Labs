<?php
include 'header.php';
include 'dbSQL.php';
 ?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Delete Project</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Delete Project
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<section class="contact-section">
    <div class="container">
        <div class="row" style="margin: auto">
            <div class="col-md-8" style="margin: auto">
                <div class="contact-form" style="margin: auto">
                    <h4>Delete Project </h4>
                    <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                    <form action="projAction.php" method="post" class="row">
                        <div class="col-md-6">
                            <Label>Projects</Label> <br>
                            <?php
                            //show advisor full name from Person table having first name and id from advisor table in dropdown and by submitting the form, the advisor id will be stored in the database
                                $query =
                                    "SELECT Project.Id, Project.Title  FROM Project";
                                $res = db::getRecords($query);
                                $designationDropdown =
                                    '<select name="title">';
                                foreach ($res as $des) {
                                    $designationDropdown .=
                                        '<option value="' .
                                        $des['Title'] .
                                        '">' .
                                        $des['Title'] .
                                        '</option>';
                                }
                                $designationDropdown .= '</select>';
                                echo $designationDropdown;
                                ?>
                        </div>
                        <div class="col-md-6 text-right" style="margin-left: 70px">
                            <input type="submit" name="projDelSubmit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>