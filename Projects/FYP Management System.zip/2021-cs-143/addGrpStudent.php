<?php
include 'header.php'; 
include 'dbSQL.php';
?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Add Student In Group</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Add Student In Group
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<section class="contact-section">
    <div class="container">
        <div class="row" style="margin: auto">
            <div class="col-md-8" style="margin: auto">
                <div class="contact-form" style="margin: auto">
                    <h4>Add Student In Group</h4>
                    <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                    <form action="grpStuAction.php" method="post" class="row">
                        <div class="col-md-6">
                            <Label>Group Id</Label> <br>
                            <?php
                                $query = 'SELECT Id FROM [Group]';
                                $res = db::getRecords($query);
                                $GroupDropdown =
                                    '<select name="grpId" required>';
                                    foreach ($res as $grpRow) {
                                    $GroupDropdown .=
                                        '<option value="' .
                                        $grpRow['Id'] .
                                        '">' .
                                        $grpRow['Id'] .
                                        '</option>';
                                }
                                $GroupDropdown .= '</select>';
                                echo $GroupDropdown;
                                ?>
                        </div>
                        <div class="col-md-6">
                            <Label>Student Name</Label> <br>
                            <?php
                                $query = 'SELECT Student.Id, FirstName FROM [Student] Join Person on Person.Id = Student.Id';
                                $res = db::getRecords($query);
                                $studentDropdown =
                                    '<select name="stuId" required>';

                                foreach ($res as $stuRow) {
                                    $studentDropdown .=
                                        '<option value="' .
                                        $stuRow['Id'] .
                                        '">' .
                                        $stuRow['FirstName'] .
                                        '</option>';
                                }
                                $studentDropdown .= '</select>';
                                echo $studentDropdown;
                                ?>
                        </div>
                        <div class="col-md-6">
                            <Label>Status</Label> <br>
                            <?php
                                $query = "SELECT * FROM Lookup where Category = 'STATUS'";
                                $res = db::getRecords($query);
                                $statusDropdown = '<select name="status">';

                                foreach($res as $stat)
                                {
                                    $statusDropdown .= '<option value="'. $stat['Id'].'">'.$stat['Value'].'</option>';
                                }
                                $statusDropdown .= '</select>';
                                echo $statusDropdown;
                            ?>
                        </div>

                        <div class="col-md-6 text-right" style="margin-top: 10px">
                            <input type="submit" name="grpSubmit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php';
?>