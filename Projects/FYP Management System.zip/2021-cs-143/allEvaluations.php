<?php
    include('header.php');
    include('dbSQL.php');
?>
<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">All Evaluations</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> All Evaluations
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->
<table class="container table table-light table-striped" style="margin-top:40px">
    <?php
        //get projects not assigned to any student
        $query = "SELECT * from Evaluation";
        $res = db::getRecords($query);    
        $section = "<thead>";
        $section .= "<tr>";
        $section .= '    <th scope="col">Sr.</th>';
        $section .= '    <th scope="col">Id</th>';
        $section .= '    <th scope="col">Name</th>';
        $section .= '    <th scope="col">Marks</th>';
        $section .= '    <th scope="col">Weightage</th>';
        $section .= '</tr>';
        $section .= '</thead>';
        $count = 1;
        echo $section;
        foreach($res as $row)
        {
            $section = "<tbody>";
            $section .= "<tr>";
            $section .= '    <th scope="row">'.$count.'</th>';
            $section .= '    <td>'.$row['Id'].'</td>';
            $section .= '    <td>'.$row['Name'].'</td>';
            $section .= '    <td>'.$row['TotalMarks'].'</td>';
            $section .= '    <td>'.$row['TotalWeightage'].'</td>';
            $section .= '</tr>';
            $section .= '</tbody>';
            echo $section;
            $count++;
        }
    ?>

</table>
<a href="javascript:window.print();" class="bisylms-btn" style="margin-left:800px; margin-bottom:100px">Print</a>

<?php
    // include('footer.php');
?>