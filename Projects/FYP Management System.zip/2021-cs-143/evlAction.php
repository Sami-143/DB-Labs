<?php
include 'dbSQL.php';

if (isset($_POST['evlSubmit'])) {
    $name = $_POST['name'];
    $marks = $_POST['marks'];
    $weightage = $_POST['weightage'];
    //validation
    if ($marks < 0 || $weightage < 0) {
        echo '<script>alert("Marks and Weightage must be positive.");</script>';
        return;
    }
    if ($weightage > 100) {
        echo '<script>alert("Weightage must be less than 100.");</script>';
        return;
    }
    //add evaluation
    $sql = "INSERT INTO Evaluation (Name, TotalMarks, TotalWeightage) VALUES ('$name', $marks, $weightage)";
    $rowCount = db::insertRecords($sql);
    if ($rowCount > 0) {
        echo '<script>alert("Record Inserted successfully.");</script>';
    } else {
        echo '<script>alert("Error in Insertion");</script>';
    }
    return;
}
if (isset($_POST['evlDelSubmit'])) {
    //delete evaluation
    $evlId = $_POST['evlId'];
    $sql = "DELETE FROM Evaluation WHERE Id = $evlId";
    $rowCount = db::deleteRecords($sql);
    if ($rowCount > 0) {
        echo '<script>alert("Record Deleted successfully.");</script>';
    } else {
        echo '<script>alert("Error in Deletion");</script>';
    }
    return;
}
if (isset($_POST['evlSearchSubmit'])) {
    $evlId = $_POST['evlId'];
    $sql = "SELECT * from Evaluation where Id = '$evlId'";
    $result = db::getRecords($sql);
    // $sql = "SELECT Created_on from Student cross join [Group] Cross join GroupStudent where [Group].Id = GroupStudent.GroupId and GroupStudent.StudentId = $result[0]['Id']";
    // $result2 = db::getRecords($sql);
    if (count($result) > 0) { ?>
<!-- Banner Start -->
<?php include 'header.php'; ?>
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Search Evaluation</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Search Evaluation
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->
<!-- Feature Course Start -->
<section class="feature-course-section">
    <div class="container">
        <div class="row shafull-container">
            <div class="col-lg-4 col-md-6 shaf-item">
                <div class="feature-course-item">
                    <div class="flipper">
                        <div class="front">
                            <div class="fcf-thumb">
                                <img src="assets/images/home/course/2.png" alt="">
                            </div>
                            <p><?php //echo $result2[0]['Created_on'] ?></p>
                            <h4><?php echo $result[0]['Name']; ?></h4>
                            <div class="fcf-bottom">
                                <a href="#"><i class="="></i>Marks:
                                    <?php echo $result[0]['TotalMarks'] ?></a>
                                <br>
                                <a href="#"><i class="="></i>Weightage:
                                    <?php echo $result[0]['TotalWeightage'] ?></a>
                            </div>
                        </div>
                        <div class="back">
                            <div class="fcf-thumb">
                                <img src="assets/images/home/course/2.png" alt="">
                            </div>
                            <!-- echo $result2[0]['Created_on']  -->
                            <!-- <a href="#" class="c-cate"></a> -->
                            <h4><a href="#"><?php echo $result[0][
                                    'Name'
                                ]  ?></a></h4>
                            <div class="ratings">
                                <span><?php // echo $result[0][
                                       // ''
                                  //  ]; ?></span>
                            </div>
                            <div class="course-price">
                                <!-- <?php // echo $result[0]['']; ?> -->
                            </div>
                            <div class="author">
                                <!-- <img src="assets/images/home/course/author.png" alt=""> -->
                                <a href="#"> </a>
                            </div>
                            <div class="fcf-bottom">
                                <a href="#"><i class="="></i>Marks: <?php echo $result[0]['TotalMarks'] ?></a>
                                <br>
                                <a href="#"><i class="="></i>Weightage:
                                    <?php echo $result[0]['TotalWeightage'] ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Feature Course End -->

<?php } else {echo '<script>alert("Record Not Found.");</script>';}
}
?>
<?php include 'footer.php'; ?>