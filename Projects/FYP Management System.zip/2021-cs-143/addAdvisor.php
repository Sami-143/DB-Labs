<?php
include 'header.php'; 
include 'dbSQL.php';
?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
                    <div class="col-lg-12">
                        <h2 class="banner-title">Add Advisor</h2>
                        <div class="bread-crumbs">
                            <a href="index.php">Home</a> <span></span> Add Advisor
                        </div>
                    </div>
        </div>
    </div>
</section>  
        <!-- Banner End -->

<section class="contact-section">
        <div class="container">
            <div class="row" style="margin: auto">
                <div class="col-md-8" style= "margin: auto">
                        <div class="contact-form" style= "margin: auto">
                            <h4>Add Advisor </h4>
                            <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                            <form action="advAction.php" method="post" class="row" >
                                <div class="col-md-6">
                                    <input type="text" name="f-name" placeholder="First Name" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" name="l-name" placeholder="Last Name" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="number" name="phone" placeholder="Contact Number" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="email" name="email" placeholder="Email Address" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="number" name="salary" placeholder="Salary" required>
                                </div>
                                <div class="col-md-6">
                                    <Label>Date of Birth</Label> <br>
                                    <input type="date" name="dob" placeholder="Date of Birth" required>
                                </div>
                                <div class="col-md-6">
                                <Label>Designation</Label> <br>
                                <?php
                                $query =
                                    "SELECT * FROM Lookup where Category = 'Designation'";
                                $res = db::getRecords($query);
                                $designationDropdown =
                                    '<select name="designation">';

                                foreach ($res as $des) {
                                    $designationDropdown .=
                                        '<option value="' .
                                        $des['Id'] .
                                        '">' .
                                        $des['Value'] .
                                        '</option>';
                                }
                                $designationDropdown .= '</select>';
                                echo $designationDropdown;
                                ?>
                                </div>
                                <div class="col-md-6">
                                    <Label>Gender</Label> <br>
                                    <?php
                                    $query =
                                        "SELECT * FROM Lookup where Category = 'GENDER'";
                                    $res = db::getRecords($query);
                                    $genderDropdown = '<select name="gender">';

                                    foreach ($res as $gen) {
                                        $genderDropdown .=
                                            '<option value="' .
                                            $gen['Id'] .
                                            '">' .
                                            $gen['Value'] .
                                            '</option>';
                                    }
                                    $genderDropdown .= '</select>';
                                    echo $genderDropdown;
                                    ?>
                                </div>
                                <div class="col-md-6 text-right" style="margin-top: 10px; margin-left: 60px">
                                    <input type="submit" name="advSubmit" value="Submit" >
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>

<?php include 'footer.php';
?>
