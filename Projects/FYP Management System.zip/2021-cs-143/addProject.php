<?php
include 'header.php'; 
include 'dbSQL.php';
?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Add Project</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Add Project
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<section class="contact-section">
    <div class="container">
        <div class="row" style="margin: auto">
            <div class="col-md-8" style="margin: auto">
                <div class="contact-form" style="margin: auto">
                    <h4>Add Project </h4>
                    <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                    <form action="projAction.php" method="post" class="row">
                        <div class="col-md-6">
                            <input type="text" name="title" placeholder="Title" required>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="description" placeholder="Description" required>
                        </div>
                        <!-- <div class="col-md-6">
                                    <input type="number" name="advisorId" placeholder="Advisor Id" required>
                                </div> -->
                        <div class="col-md-6">
                            <Label>Advisor Id</Label> <br>
                            <?php
                            //show advisor full name from Person table having first name and id from advisor table in dropdown and by submitting the form, the advisor id will be stored in the database
                                $query =
                                    "SELECT Advisor.Id, Person.FirstName FROM Advisor Inner Join Person on Advisor.Id = Person.Id";
                                $res = db::getRecords($query);
                                $designationDropdown =
                                    '<select name="AdvisorId">';
                                foreach ($res as $des) {
                                    $designationDropdown .=
                                        '<option value="' .
                                        $des['Id'] .
                                        '">' .
                                        $des['FirstName'] .
                                        '</option>';
                                }
                                $designationDropdown .= '</select>';
                                echo $designationDropdown;
                                ?>
                        </div>
                        <div class="col-md-6">
                            <Label>Advisor Role</Label> <br>
                            <?php
                                $query =
                                    "SELECT * FROM Lookup where Category = 'ADVISOR_ROLE'";
                                $res = db::getRecords($query);
                                $designationDropdown =
                                    '<select name="advisorRole">';
                                foreach ($res as $des) {
                                    $designationDropdown .=
                                        '<option value="' .
                                        $des['Id'] .
                                        '">' .
                                        $des['Value'] .
                                        '</option>';
                                }
                                $designationDropdown .= '</select>';
                                echo $designationDropdown;
                                ?>
                        </div>
                        <div class="col-md-6">
                            <Label>Assignment Date</Label> <br>
                            <input type="date" name="assDate" placeholder="Assignment Date" required>
                        </div>
                        <div class="col-md-6 text-right" style="margin-top: 10px">
                            <input type="submit" name="projSubmit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php';
?>