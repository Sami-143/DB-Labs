<?php
    include_once 'dbSQL.php';
if (isset($_POST['stuSubmit'])) {
    $regNum = $_POST['regNum'];
    $fName = $_POST['f-name'];
    $lName = $_POST['l-name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    //validations
    if ($regNum < 0) {
        echo '<script>alert("Registration Number should be greater than 0.");</script>';
        return;
    }
    if (!preg_match("/^[a-zA-Z ]*$/", $fName)) {
        echo '<script>alert("First Name should contain only letters and white space.");</script>';
        return;
    }
    if (!preg_match("/^[a-zA-Z ]*$/", $lName)) {
        echo '<script>alert("Last Name should contain only letters and white space.");</script>';
        return;
    }
    if (!preg_match("/^[0-9]*$/", $phone)) {
        echo '<script>alert("Phone Number should contain only numbers.");</script>';
        return;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo '<script>alert("Invalid email format.");</script>';
        return;
    }
    $dob = date('Y-m-d', strtotime($dob));
    $today = date("Y-m-d");
    if ($dob > $today) {
        echo '<script>alert("Date of Birth should be less than current date.");</script>';
        return;
    }
    //check if email already exist
    $sql = "SELECT Person.Id FROM Person WHERE email = '$email'";
    $result = db::getRecords($sql);
    if (count($result) > 0) {
        echo '<script>alert("Email already exist.");</script>';
        return;
    }
    //check if registration number already exist
    $sql = "SELECT * FROM Student WHERE RegistrationNo = '$regNum'";
    $result = db::getRecords($sql);
    if (count($result) > 0) {
        echo '<script>alert("Registration Number already exist.");</script>';
        return;
    } else {
        $sql = "INSERT INTO Person (FirstName, LastName, Contact, Email, DateofBirth, Gender) 
        VALUES ('$fName', '$lName', '$phone', '$email', '$dob', '$gender')";
        $rowCount = db::insertRecords($sql);
        $sql = "INSERT INTO Student (RegistrationNo, id) VALUES ('$regNum', (SELECT MAX(Id) FROM Person))";
        $rowCount = db::insertRecords($sql);
        if ($rowCount > 0) {
            echo '<script>alert("Record inserted successfully.");</script>';
        } else {
            echo '<script>alert("Error in inserting");</script>';
        }
    }
    return;
}
if (isset($_POST['stuDelSubmit'])) {
    $regNum = $_POST['RegistrationNo'];
    $fName = $_POST['studentname'];
    $sql = "SELECT Id FROM Student WHERE RegistrationNo = '$regNum'";
    $id = db::getRecords($sql);
    $sql = "DELETE FROM Student WHERE RegistrationNo = '$regNum'";
    $rowCount = db::deleteRecords($sql);
    $id = $id[0]['Id'];
    $sql = "DELETE FROM Person WHERE Person.Id = $id";
    $rowCount = db::deleteRecords($sql);
    if ($rowCount > 0) {
        echo '<script>alert("Record Deleted successfully.");</script>';
    } else {
        echo '<script>alert("Error in Deleting");</script>';
    }
    return;
}
//update student
if (isset($_POST['stuupdSubmit'])){
    // echo '<script>alert("Update");</script>';
    $regNum = $_POST['RegistrationNo'];
    $fName = $_POST['f-name'];
    $lName = $_POST['l-name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];
    
    //validations
    if ($regNum < 0) {
        echo '<script>alert("Registration Number should be greater than 0.");</script>';
        return;
    }
    if (!preg_match("/^[a-zA-Z ]*$/", $fName)) {
        echo '<script>alert("First Name should contain only letters and white space.");</script>';
        return;
    }
    if (!preg_match("/^[a-zA-Z ]*$/", $lName)) {
        echo '<script>alert("Last Name should contain only letters and white space.");</script>';
        return;
    }
    if (!preg_match("/^[0-9]*$/", $phone)) {
        echo '<script>alert("Phone Number should contain only numbers.");</script>';
        return;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo '<script>alert("Invalid email format.");</script>';
        return;
    }
//date of birth should be less than current date
    $dob = date('Y-m-d', strtotime($dob));
    $today = date("Y-m-d");
    if ($dob > $today) {
        echo '<script>alert("Date of Birth should be less than current date.");</script>';
        return;
    }
        
    $sql = "UPDATE Person SET FirstName = '$fName', LastName = '$lName', Contact = '$phone', Email = '$email', DateofBirth = '$dob' WHERE Id = (SELECT Id FROM Student WHERE RegistrationNo = '$regNum')";
    $rowCount = db::updateRecords($sql);
    if ($rowCount > 0) {
        echo '<script>alert("Record Updated successfully.");</script>';
    } else {
        echo '<script>alert("Error in Updating");</script>';
    }
    return;
}
if (isset($_POST['stuSearchSubmit'])) {
    $regNum = $_POST['RegistrationNo'];
    $sql = "SELECT * FROM Person WHERE Id = (SELECT Id FROM Student WHERE RegistrationNo = '$regNum')";
    $result = db::getRecords($sql);
   
    if (count($result) > 0) { ?>
<!-- Banner Start -->
<?php include 'header.php'; ?>
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Student Data</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Student Data
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->
<!-- Feature Course Start -->
<section class="feature-course-section">
    <div class="container">
        <div class="row shafull-container">
            <div class="col-lg-4 col-md-6 shaf-item">
                <div class="feature-course-item">
                    <div class="flipper">
                        <div class="front">
                            <div class="fcf-thumb">
                                <img src="assets/images/home/course/2.png" alt="">
                            </div>
                            <p><?php //echo $result2[0]['Created_on'] ?></p>
                            <h4><?php echo $result[0]['FirstName']; ?></h4>
                            <div class="fcf-bottom">
                                <?php   if ($result[0]['Gender'] == 1) {
                                            $temp = 'Male';
                                        } else {
                                            $temp = 'Female';
                                        }
                                ?>
                                <a href="#"><i class="icon_profile"></i><?php echo $temp; ?></a>
                            </div>
                        </div>
                        <div class="back">
                            <div class="fcf-thumb">
                                <img src="assets/images/home/course/2.png" alt="">
                            </div>
                            <!-- echo $result2[0]['Created_on']  -->
                            <!-- <a href="#" class="c-cate"></a> -->
                            <h4><a href="#"><?php echo $result[0][
                                    'FirstName'
                                ] . 
                                    ' ' .
                                    $result[0]['LastName']; ?></a></h4>
                            <div class="ratings">
                                <span><?php echo $result[0][
                                        'Email'
                                    ]; ?></span>
                            </div>
                            <div class="course-price">
                                <?php echo $result[0]['Contact']; ?>
                            </div>
                            <div class="author">
                                <img src="assets/images/home/course/author.png" alt="">
                                <a href="#"> </a>
                            </div>
                            <div class="fcf-bottom">
                                <a href="#"><i class="icon_profile"></i><?php echo $temp; ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Feature Course End -->

<?php } else {
    echo '<script>alert("Record Not Found. ");</script>' ;}
}
?>
<?php include 'footer.php'; ?>