<?php
include 'dbSQL.php';

if (isset($_POST['grpSubmit'])) {
    $groupId = $_POST['grpId'];
    $stuId = $_POST['stuId'];
    $status = $_POST['status'];
    //validations

    $sql = "SELECT * FROM GroupStudent WHERE GroupId = '$groupId' and StudentId = '$stuId'";
    $result = db::getRecords($sql);
    
    if (count($result) > 0) {
        echo '<script>alert("Record already exists.");</script>';
        return;
    }
    $sql = "SELECT * FROM GroupStudent WHERE GroupId = '$groupId' and Status = 1 or Status = 2";
    $result = db::getRecords($sql);
    if (count($result) > 0) {
        echo '<script>alert("Group already has a leader.");</script>';
        return;
    }
    $sql = "SELECT * FROM GroupStudent WHERE StudentId = '$stuId' and Status = 1 or Status = 2";
    $result = db::getRecords($sql);
    if (count($result) > 0) {
        echo '<script>alert("Student already has a group.");</script>';
        return;
    }
    //get current date as assDate
    $assDate = date('Y-m-d');
    $sql = "INSERT INTO GroupStudent (GroupId, StudentId, AssignmentDate, Status) VALUES ('$groupId', '$stuId', '$assDate', '$status')";
    $rowCount = db::insertRecords($sql);
    if ($rowCount > 0) {
        echo '<script>alert("Record inserted successfully.");</script>';
    } else {
        echo '<script>alert("Error in inserting");</script>';
    }
    return;
}
if (isset($_POST['grpDelSubmit'])) {
    $groupId = $_POST['grpId'];
    $stuId = $_POST['stuId'];
    //validations
    //don't add student if its already in any group
    
    $sql = "SELECT * FROM GroupStudent WHERE GroupId = '$groupId' and StudentId = '$stuId'";
    $result = db::getRecords($sql);
    if (count($result) == 0) {
        echo '<script>alert("Record does not exist.");</script>';
        return;
    }
    $sql = "DELETE FROM GroupStudent WHERE GroupId = '$groupId' and StudentId = '$stuId'";
    $rowCount = db::deleteRecords($sql);
    if ($rowCount > 0) {
        echo '<script>alert("Record deleted successfully.");</script>';
    } else {
        echo '<script>alert("Error in deleting");</script>';
    }
    return;
}
if (isset($_POST['stuSearchSubmit'])) {
    $regNum = $_POST['regNum'];
    $fName = $_POST['f-name'];
    $sql = "SELECT * FROM Person WHERE Id = (SELECT Id FROM Student WHERE RegistrationNo = '$regNum') and FirstName = '$fName'";
    $result = db::getRecords($sql);
    // $sql = "SELECT Created_on from Student cross join [Group] Cross join GroupStudent where [Group].Id = GroupStudent.GroupId and GroupStudent.StudentId = $result[0]['Id']";
    // $result2 = db::getRecords($sql);
    if (count($result) > 0) { ?>
<!-- Banner Start -->
<?php include 'header.php'; ?>
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Search Student</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Search Student
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->
<section class="contact-section">
    <div class="container">
        <div class="row" style="margin: auto">
            <div class="col-md-8" style="margin: auto">
                <div class="contact-form" style="margin: auto">
                    <h4>Search Student </h4>
                    <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                    <form action="action.php" method="post" class="row">
                        <div class="col-md-6">
                            <input type="text" name="regNum" placeholder="Registration Number">
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="f-name" placeholder="First Name">
                        </div>
                        <div class="col-md-6 text-right" style="margin-top: 10px">
                            <input type="submit" name="stuSearchSubmit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Feature Course Start -->
<section class="feature-course-section">
    <div class="container">
        <div class="row shafull-container">
            <div class="col-lg-4 col-md-6 shaf-item">
                <div class="feature-course-item">
                    <div class="flipper">
                        <div class="front">
                            <div class="fcf-thumb">
                                <img src="assets/images/home/course/2.png" alt="">
                            </div>
                            <p><?php //echo $result2[0]['Created_on'] ?></p>
                            <h4><?php echo $result[0]['FirstName']; ?></h4>
                            <div class="fcf-bottom">
                                <?php // if ($result[0]['Gender'] == 1) {
                                        //$temp = 'Male';
                                    // } else {
                                        // $temp = 'Female';
                                    //} ?>
                                <a href="#"><i class="icon_profile"></i><?php echo $temp; ?></a>
                            </div>
                        </div>
                        <div class="back">
                            <div class="fcf-thumb">
                                <img src="assets/images/home/course/2.png" alt="">
                            </div>
                            <!-- echo $result2[0]['Created_on']  -->
                            <!-- <a href="#" class="c-cate"></a> -->
                            <h4><a href="#"><?php echo $result[0][
                                    'FirstName'
                                ] . 
                                    ' ' .
                                    $result[0]['LastName']; ?></a></h4>
                            <div class="ratings">
                                <span><?php echo $result[0][
                                        'Email'
                                    ]; ?></span>
                            </div>
                            <div class="course-price">
                                <?php echo $result[0]['Contact']; ?>
                            </div>
                            <div class="author">
                                <img src="assets/images/home/course/author.png" alt="">
                                <a href="#"> </a>
                            </div>
                            <div class="fcf-bottom">
                                <a href="#"><i class="icon_profile"></i><?php echo $temp; ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Feature Course End -->

<?php } else {echo '<script>alert("Record Not Found.");</script>';}
}
?>
<?php include 'footer.php'; ?>