<?php
    include "header.php";
    include 'dbSQL.php';
?>


<!-- Hero Banner Start -->
<section class="hero-banner-1" style="background-image: url(assets/images/home/banner.png);">
    <!-- shape -->
    <div class="shape-wrap">
        <div class="b-shape-1">
            <img src="assets/images/home/shape-1.png" alt="">
        </div>
        <div class="b-shape-2">
            <img src="assets/images/home/shape-2.png" alt="">
        </div>
        <div class="b-shape-3">
            <img src="assets/images/home/shape-3.png" alt="">
        </div>
        <div class="b-shape-4">
            <img src="assets/images/home/shape-4.png" alt="">
        </div>
    </div>
    <!-- shape -->
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-5">
                <div class="hero-content">
                    <h2>FYP Management System</h2>
                    <p>
                        Say goodbye to the headaches of traditional project management and embrace a modern, efficient
                        approach with our FYP management system.
                    </p>
                    <!-- <a href="#" class="bisylms-btn">Ready to Get Started?</a> -->
                </div>
            </div>
            <div class="col-lg-7 col-md-7">
                <div class="banner-thumb">
                    <img src="assets/images/home/layer.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<!-- Course Start -->
<section class="popular-course-section">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h2 class="sec-title"><span>What</span> We are managing</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="course-wrapper">
                    <div class="course-item-1 text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="74"
                            height="60" viewBox="0 0 74 60">
                            <defs>
                                <style>
                                .cls-1 {
                                    fill: url(#pattern);
                                }
                                </style>
                                <pattern id="pattern" preserveAspectRatio="xMidYMid slice" width="100%" height="100%"
                                    viewBox="0 0 74 60">
                                    <image width="74" height="60" xlink:href="assets/images/home/desktop1-image.png" />
                                </pattern>
                            </defs>
                            <path id="desktop1" class="cls-1" d="M0,0H74V60H0Z" />
                        </svg>
                        <?php 
                        //get the count of projects in project table
                        $sql = "SELECT COUNT(*) AS total FROM project";
                        $result = db::getRecords($sql);
                        echo '<h4><a href="single-course.html">Projects '.' ( ' . $result[0]["total"] . ' ) ' . ' </a></h4>';
                        ?>
                    </div>
                    <div class="course-item-1 text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="64"
                            height="64" viewBox="0 0 64 64">
                            <image id="data" width="64" height="64" xlink:href="assets/images/home/data-image.png" />
                        </svg>
                        <?php 
                        //get the count of projects in project table
                        $sql = "SELECT COUNT(*) AS total FROM [Group]";
                        $result = db::getRecords($sql);
                        echo '<h4><a href="single-course.html">Groups '.' ( ' . $result[0]["total"] . ' ) ' . ' </a></h4>';
                        ?>
                    </div>
                    <div class="course-item-1 text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="74"
                            height="70" viewBox="0 0 74 70">
                            <image id="proposal" width="74" height="70"
                                xlink:href="assets/images/home/proposal-image.png" />
                        </svg>
                        <?php 
                        //get the count of projects in project table
                        $sql = "SELECT COUNT(*) AS total FROM Advisor";
                        $result = db::getRecords($sql);
                        echo '<h4><a href="single-course.html">Advisors '.' ( ' . $result[0]["total"] . ' ) ' . ' </a></h4>';
                        ?>
                    </div>
                    <div class="course-item-1 text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="80"
                            height="67" viewBox="0 0 80 67">
                            <image id="chat" width="80" height="67" xlink:href="assets/images/home/chat-image.png" />
                        </svg>
                        <?php 
                        //get the count of projects in project table
                        $sql = "SELECT COUNT(*) AS total FROM Evaluation";
                        $result = db::getRecords($sql);
                        echo '<h4><a href="single-course.html">Evaluations '.' ( ' . $result[0]["total"] . ' ) ' . ' </a></h4>';
                        ?>
                    </div>
                    <div class="course-item-1 text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="58"
                            height="73" viewBox="0 0 58 73">
                            <image id="mind" width="58" height="73" xlink:href="assets/images/home/mind-image.png" />
                        </svg>
                        <?php 
                        //get the count of projects in project table
                        $sql = "SELECT COUNT(*) AS total FROM Student";
                        $result = db::getRecords($sql);
                        echo '<h4><a href="single-course.html">Students '.' ( ' . $result[0]["total"] . ' ) ' . ' </a></h4>';
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Course End -->

<!-- Feature Course Start -->
<section class="feature-course-section">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <h2 class="sec-title">Projects</h2>
            </div>
        </div>
        <div class="row shafull-container">
            <?php 
            // Array of banner images
                $banners = array(
                    '1.png',
                    '2.png',
                    '3.png'
                );
                
                $sql = "SELECT * FROM Project";
                $result = db::getRecords($sql);
                //get project details from projectadvisor table 
                $sql2 = "SELECT * FROM ProjectAdvisor";
                $result2 = db::getRecords($sql2);
               
                foreach($result as $temp)
                {
                    // Randomly select a banner from the array
                    $advisorName = " ";
                    $banner = $banners[array_rand($banners)];
                    
                    $sql3 = "SELECT 
                            p.Id AS ProjectId,
                            p.Title AS ProjectTitle,
                            g.Id AS GroupId,
                            COUNT(gs.StudentId) AS NumStudents
                            FROM Project p
                            INNER JOIN GroupProject gp ON p.Id = gp.ProjectId
                            INNER JOIN [Group] g ON g.Id = gp.GroupId
                            INNER JOIN GroupStudent gs ON gs.GroupId = g.Id
                            GROUP BY p.Id, p.Title, g.Id";
                    $result3 = db::getRecords($sql3);
                     // set initial value of NumStudents to 0
                    $query = "SELECT ProjectId, AssignmentDate FROM GroupProject INNER JOIN Project ON Project.Id = GroupProject.ProjectId";
                    $result4 = db::getRecords($query);
                    $NumStudents = 0;
                    foreach($result3 as $temp2) {
                        // check if the current project matches the project from the inner loop
                        if($temp['Id'] == $temp2['ProjectId']) {
                            $NumStudents = $temp2['NumStudents'];
                            break;
                        }
                    }  
                    $assignmentDate = " ";
                    foreach($result4 as $temp3) {
                        // check if the current project matches the project from the inner loop
                        if($temp['Id'] == $temp3['ProjectId']) {
                            $assignmentDate = date('Y-m-d', strtotime($temp3['AssignmentDate']));
                            break;
                        }
                    }
                    $section = ' <div class="col-lg-4 col-md-6 shaf-item"> ';   
                    $section .= '    <div class="feature-course-item">';
                    $section .= '                     <div class="flipper"> ';
                    $section .= '         <div class="front"> ';
                    $section .= '             <div class="fcf-thumb"> ';
                    $section .= '                 <img src="assets/images/home/course/' . $banner . '" alt=""> ';
                    $section .= '             </div> ';
                    $section .= '               <h4>' . (isset($temp['Title']) ? $temp['Title'] : '') . '</h4>';
                    $section .= '             <div class="fcf-bottom"> ';
                    $section .= '                 <a href="#"><i class="icon_profile"></i>'. $NumStudents . '</a> ';
                    $section .= '             </div> ';
                    $section .= '         </div> ';
                    $section .= '         <div class="back"> ';
                    $section .= '             <div class="fcf-thumb"> ';
                    $section .= '                 <img src="assets/images/home/course/' . $banner . '" alt=""> ';
                    $section .= '             </div> ';
                    $section .= '             <h4><a href="#">' . (isset($temp['Title']) ? $temp['Title'] : '') . '</a></h4> ';
                    $section .= '             <div class="course-price" style = "font-size: 15px"> ';
                    $section .= '                 ' . "Description: " . (isset( $temp['Description']) ?  $temp['Description'] : '') . ' ';
                    $section .= '             </div> ';
                    $section .= '             <div class="course-price" style = "font-size: 15px"> ';
                    $query2 = "SELECT FirstName, Project.Id FROM Project INNER JOIN ProjectAdvisor ON $temp[Id] = ProjectAdvisor.ProjectId INNER JOIN Advisor ON Advisor.Id = ProjectAdvisor.AdvisorId INNER JOIN Person ON Person.Id = Advisor.Id";
                    $result5 = db::getRecords($query2);
                    if ($result5 !== null) {
                      foreach ($result5 as $row) {
                        if($temp['Id'] == $row['Id']) {
                            $advisorName = $row['FirstName'];
                            $section .= '                 ' . "Advisors: " . (isset($advisorName) ?  $advisorName : '') . ' ';
                          }
                        }
                    }
                    else {
                    }
                    $section .= '             </div> ';
                    $section .= '             <div class="fcf-bottom"> ';
                    $section .= '                 <a href="lesson.php?ProjectId=' . $assignmentDate . '"><i class=""></i>' . $assignmentDate . '</a> ';
                    $section .= '                 <a href="#"><i class="icon_profile"></i>'. $NumStudents . '</a> ';
                    $section .= '             </div> ';
                    $section .= '         </div> ';
                    $section .= '     </div> ';
                    $section .= ' </div> ';
                    $section .= ' </div> ';
                    echo $section;
                }
            ?>
        </div>
    </div>
</section>
<!-- Feature Course End -->

<?php
    include "footer.php"
?>