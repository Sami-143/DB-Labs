<?php
include 'header.php';
include 'dbSQL.php';
?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Search Group</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Search Group
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<section class="contact-section">
    <div class="container">
        <div class="row" style="margin: auto">
            <div class="col-md-8" style="margin: auto">
                <div class="contact-form" style="margin: auto">
                    <h4>Search Group </h4>
                    <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                    <form action="grpAction.php" method="post" class="row">
                        <div class="col-md-6">
                            <Label>Group Id</Label> <br>
                            <?php
                                $query = 'SELECT Id FROM [Group]';
                                $res = db::getRecords($query);
                                $GroupDropdown =
                                    '<select name="grpId" required>';

                                foreach ($res as $grpRow) {
                                    $GroupDropdown .=
                                        '<option value="' .
                                        $grpRow['Id'] .
                                        '">' .
                                        $grpRow['Id'] .
                                        '</option>';
                                }
                                $GroupDropdown .= '</select>';
                                echo $GroupDropdown;
                                ?>
                        </div>
                        <div class="col-md-6 text-right" style="margin-top: 10px">
                            <input type="submit" name="grpSearchSubmit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>