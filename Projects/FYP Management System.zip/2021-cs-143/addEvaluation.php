<?php
include 'header.php'; 
include 'dbSQL.php';
?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Add Evaluation</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Add Evaluation
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<section class="contact-section">
    <div class="container">
        <div class="row" style="margin: auto">
            <div class="col-md-8" style="margin: auto">
                <div class="contact-form" style="margin: auto">
                    <h4>Add Evaluation </h4>
                    <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                    <form action="evlAction.php" method="post" class="row">
                        <div class="col-md-6">
                            <input type="text" name="name" placeholder="Name" required>
                        </div>
                        <div class="col-md-6">
                            <input type="number" name="marks" placeholder="Total Marks" required>
                        </div>
                        <div class="col-md-6">
                            <input type="number" name="weightage" placeholder="Total Weightage" required>
                        </div>
                        <div class="col-md-6 text-right" style="margin-top: 10px; margin-left:230px;">
                            <input type="submit" name="evlSubmit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php';
?>