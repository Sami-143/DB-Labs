<?php
include 'header.php'; 
include 'dbSQL.php';
?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Evaluate Group</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Evaluate Group
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<section class="contact-section">
    <div class="container">
        <div class="row" style="margin: auto">
            <div class="col-md-8" style="margin: auto">
                <div class="contact-form" style="margin: auto">
                    <h4>Evaluate Group </h4>
                    <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                    <form action="evlGrpAction.php" method="post" class="row">
                        <div class="col-md-6">
                            <input type="number" name="obtMarks" placeholder="Obtained Marks" required>
                        </div>
                        <div class="col-md-6">
                            <Label>Group Id</Label> <br>
                            <?php
                            //get groups who got assigned a project
                                $query =
                                    "SELECT 
                                    g.Id AS GroupId,
                                    p.Title AS ProjectTitle,
                                    gp.AssignmentDate AS ProjectAssignedDate
                                FROM 
                                    [Group] g
                                    INNER JOIN GroupProject gp ON g.Id = gp.GroupId
                                    INNER JOIN Project p ON gp.ProjectId = p.Id";

                                $res = db::getRecords($query);
                               
                                $projectDropdown =
                                    '<select name="grpId" required>';

                                foreach ($res as $proRow) {
                                    $projectDropdown .=
                                        '<option value="' .
                                        $proRow['GroupId'] .
                                        '">' .
                                        $proRow['GroupId'] .
                                        '</option>';
                                }
                                $projectDropdown .= '</select>';
                                echo $projectDropdown;
                            ?>
                        </div>
                        <div class="col-md-6">
                            <Label>Evaluation Name</Label> <br>
                            <?php
                                $query =
                                    "SELECT Id, [Name] as evlName FROM [Evaluation]";
                                $res = db::getRecords($query);
                                $projectDropdown =
                                    '<select name="evlId" required>';
                                foreach ($res as $proRow) {
                                    $projectDropdown .=
                                        '<option value="' .
                                        $proRow['Id'] .
                                        '">' .
                                        $proRow['evlName'] .
                                        '</option>';
                                }
                                $projectDropdown .= '</select>';
                                echo $projectDropdown;
                            ?>
                        </div>

                        <div class="col-md-6 text-right" style="margin-top: 10px; margin-left:230px;">
                            <input type="submit" name="evlGrpSubmit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php';
?>