<?php
include 'header.php'; 
include 'dbSQL.php';
?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Update Student</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Update Student
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<section class="contact-section">
    <div class="container">
        <div class="row" style="margin: auto">
            <div class="col-md-8" style="margin: auto">
                <div class="contact-form" style="margin: auto">
                    <h4>Update Student </h4>
                    <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                    <form action="action.php" method="post" class="row">
                        <div class="col-md-6">
                            <Label>Registration Number</Label> <br>
                            <?php
                                $query = 'SELECT FirstName as studentname, RegistrationNo FROM Person Inner Join Student on Student.Id = Person.Id';
                                $res = db::getRecords($query);
                                $GroupDropdown =
                                    '<select name="RegistrationNo" required>';

                                foreach ($res as $grpRow) {
                                    $GroupDropdown .=
                                        '<option value="' .
                                        $grpRow['RegistrationNo'] .
                                        '">' .
                                        $grpRow['RegistrationNo'] .
                                        '</option>';
                                }
                                $GroupDropdown .= '</select>';
                                echo $GroupDropdown;
                                ?>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="f-name" placeholder="First Name" required>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="l-name" placeholder="Last Name" required>
                        </div>
                        <div class="col-md-6">
                            <input type="number" name="phone" placeholder="Contact Number" required>
                        </div>
                        <div class="col-md-6">
                            <input type="email" name="email" placeholder="Email Address" required>
                        </div>
                        <div class="col-md-6">
                            <Label>Date of Birth</Label> <br>
                            <input type="date" name="dob" placeholder="Date of Birth" required>
                        </div>
                        <div class="col-md-6">
                            <Label>Gender</Label> <br>
                            <?php
                                $query = "SELECT * FROM Lookup where Category = 'GENDER'";
                                $res2 = db::getRecords($query);
                                $genderDropdown = '<select name="gender" required>';

                                foreach($res2 as $gen)
                                {
                                    $genderDropdown .= '<option value="'. $gen['Id'].'">'.$gen['Value'].'</option>';
                                }
                                $genderDropdown .= '</select>';
                                echo $genderDropdown;
                            ?>
                        </div>
                        <div class="col-md-6 text-right" style="margin-top: 10px">
                            <input type="submit" name="stuupdSubmit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php';
?>