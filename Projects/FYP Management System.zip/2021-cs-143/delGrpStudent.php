<?php
include 'header.php';
include 'dbSQL.php';
 ?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Delete Project</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Delete Project
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<section class="contact-section">
    <div class="container">
        <div class="row" style="margin: auto">
            <div class="col-md-8" style="margin: auto">
                <div class="contact-form" style="margin: auto">
                    <h4>Delete Student From Group</h4>
                    <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                    <form action="grpStuAction.php" method="post" class="row">
                        <div class="col-md-6">
                            <Label>Group Id</Label> <br>
                            <?php
                                $query = 'SELECT GroupId, StudentId FROM [GroupStudent]';
                                $res = db::getRecords($query);
                                $GroupDropdown =
                                    '<select name="grpId" required>';

                                foreach ($res as $grpRow) {
                                    $GroupDropdown .=
                                        '<option value="' .
                                        $grpRow['GroupId'] .
                                        '">' .
                                        $grpRow['GroupId'] .
                                        '</option>';
                                }
                                $GroupDropdown .= '</select>';
                                echo $GroupDropdown;
                                ?>
                        </div>
                        <div class="col-md-6">
                            <Label>Student Id</Label> <br>
                            <?php
                                $query = 'SELECT StudentId FROM [GroupStudent]';
                                $res = db::getRecords($query);
                                $GroupDropdown =
                                    '<select name="stuId" required>';

                                foreach ($res as $grpRow) {
                                    $GroupDropdown .=
                                        '<option value="' .
                                        $grpRow['StudentId'] .
                                        '">' .
                                        $grpRow['StudentId'] .
                                        '</option>';
                                }
                                $GroupDropdown .= '</select>';
                                echo $GroupDropdown;
                                ?>
                        </div>
                        <div class="col-md-6 text-right" style="margin-left: 70px; margin-top: 20px">
                            <input type="submit" name="grpDelSubmit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>