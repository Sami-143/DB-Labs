<?php
include 'header.php'; 
include 'dbSQL.php';
?>
        <!-- Banner Start -->
        <section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="banner-title">Instructor</h2>
                        <div class="bread-crumbs">
                            <a href="index.html">Home</a> <span></span> Instructor
                        </div>
                    </div>
                </div>
            </div>
        </section>  
        <!-- Banner End -->

        <!-- Teachers Section Start -->
        <section class="instructor-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h2 class="sec-title mb-15"><span>Classes Taught by</span> Real Creators</h2>
                        <p class="sec-desc">
                            Online education is a flexible instructional delivery system that encompasses any<br> kind of learning that takes place via the Internet.
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="teacher-item">
                            <div class="teacher-thumb">
                                <img src="assets/images/home2/teacher/1.png" alt="">
                                <div class="teacher-social">
                                    <a href="#"><i class="social_youtube"></i></a>
                                    <a href="#"><i class="social_pinterest"></i></a>
                                </div>
                            </div>
                            <div class="teacher-meta">
                                <h5><a href="#">Dianne Ameter</a></h5>
                                <p>Illustrator</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="teacher-item">
                            <div class="teacher-thumb">
                                <img src="assets/images/home2/teacher/2.png" alt="">
                                <div class="teacher-social">
                                    <a href="#"><i class="social_facebook"></i></a>
                                    <a href="#"><i class="social_twitter"></i></a>
                                </div>
                            </div>
                            <div class="teacher-meta">
                                <h5><a href="#">Hugh Saturation</a></h5>
                                <p>Photographer</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="teacher-item">
                            <div class="teacher-thumb">
                                <img src="assets/images/home2/teacher/3.png" alt="">
                                <div class="teacher-social">
                                    <a href="#"><i class="social_vimeo"></i></a>
                                    <a href="#"><i class="social_tumblr"></i></a>
                                </div>
                            </div>
                            <div class="teacher-meta">
                                <h5><a href="#">Jim Séchen</a></h5>
                                <p>Stylist & Author</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="teacher-item">
                            <div class="teacher-thumb">
                                <img src="assets/images/home2/teacher/4.png" alt="">
                                <div class="teacher-social">
                                    <a href="#"><i class="social_dribbble"></i></a>
                                    <a href="#"><i class="social_linkedin"></i></a>
                                </div>
                            </div>
                            <div class="teacher-meta">
                                <h5><a href="#">Eric Widget</a></h5>
                                <p>Designer</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="teacher-item">
                            <div class="teacher-thumb">
                                <img src="assets/images/home2/teacher/5.png" alt="">
                                <div class="teacher-social">
                                    <a href="#"><i class="social_youtube"></i></a>
                                    <a href="#"><i class="social_pinterest"></i></a>
                                </div>
                            </div>
                            <div class="teacher-meta">
                                <h5><a href="#">Jim Séchen</a></h5>
                                <p>Professor</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="teacher-item">
                            <div class="teacher-thumb">
                                <img src="assets/images/home2/teacher/6.png" alt="">
                                <div class="teacher-social">
                                    <a href="#"><i class="social_facebook"></i></a>
                                    <a href="#"><i class="social_twitter"></i></a>
                                </div>
                            </div>
                            <div class="teacher-meta">
                                <h5><a href="#">Eric Abidal</a></h5>
                                <p>Developer</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="teacher-item">
                            <div class="teacher-thumb">
                                <img src="assets/images/home2/teacher/7.png" alt="">
                                <div class="teacher-social">
                                    <a href="#"><i class="social_vimeo"></i></a>
                                    <a href="#"><i class="social_tumblr"></i></a>
                                </div>
                            </div>
                            <div class="teacher-meta">
                                <h5><a href="#">Keny White</a></h5>
                                <p>Illustratorr</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="teacher-item">
                            <div class="teacher-thumb">
                                <img src="assets/images/home2/teacher/8.png" alt="">
                                <div class="teacher-social">
                                    <a href="#"><i class="social_dribbble"></i></a>
                                    <a href="#"><i class="social_linkedin"></i></a>
                                </div>
                            </div>
                            <div class="teacher-meta">
                                <h5><a href="#">Carolina Martin</a></h5>
                                <p>App Designer</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Teachers Section End -->

<?php include 'footer.php';
?>
