<?php
include 'header.php'; 
include 'dbSQL.php';
?>
<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Students</h2>
                <div class="bread-crumbs">
                    <a href="index.html">Home</a> <span></span> Students
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<!-- Teachers Section Start -->
<section class="instructor-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2 class="sec-title mb-15"><span>Our Hardworking </span>Students</h2>
                <p class="sec-desc">
                    <!-- Online education is a flexible instructional delivery system that encompasses any<br> kind of
                    learning that takes place via the Internet. -->
                </p>
            </div>
        </div>
        <div class="row">
            <?php 
              $images = array(
                '1.png',
                '2.png',
                '3.png',
                '4.png',
                '5.png',
                '6.png',    
                '8.png',    
                '7.png'
            );
            
                $query = "SELECT * FROM Student INNER JOIN Person ON Student.Id = Person.Id";
                $result = db::getRecords($query);
                
                foreach($result as $temp){
                    
                    $image = $images[array_rand($images)];
                    $section= '<div class="col-lg-3 col-md-6">';
                    $section .= '    <div class="teacher-item">';
                    // $section .= '        <div class="teacher-thumb">';
                    $section .= '            <img src="assets/images/home2/teacher/'. $image .'" alt="">';
                    // $section .= '            <div class="teacher-social">';
                    // $section .= '                <a href="#"><i class="social_youtube"></i></a>';
                    // $section .= '                <a href="#"><i class="social_pinterest"></i></a>';
                    // $section .= '            </div>';
                    // $section .= '        </div>';
                    $section .= '        <div class="teacher-meta">';
                    $section .= '            <h5><a href="#">'. $temp['FirstName'] . "(" . $temp['RegistrationNo'] . ")" .'</a></h5>';
                    //show gendre of student by using the id from lookup(id, value, category)
                    //code: 
                    $query = "SELECT [Value] FROM Lookup WHERE Id = '$temp[Gender]'";
                    $result = db::getRecords($query);
                    if (!is_null($result)) {
                        $temp['Gender'] = $result[0]['Value'];
                    }
                    $section .= '            <p>'. $temp['Gender'] .'</p>';
                    $section .= '        </div>';
                    $section .= '    </div>';
                    $section .= '</div>';
                    echo $section;
                }
            ?>
        </div>
    </div>
</section>
<!-- Teachers Section End -->

<?php include 'footer.php';
?>