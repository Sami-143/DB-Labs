  <!-- Footer Section Start -->
  <footer class="footer-1">
      <div class="container">
          <!-- <div class="row">
                <div class="col-md-12">
                    <div class="cta-wrapper">
                        <img src="assets/images/home/2.png" alt="">
                        <h3>You can be your own Guiding star with our help!</h3>
                        <a href="#" class="bisylms-btn">Get Started Now</a>
                    </div>
                </div>
            </div> -->
          <div class="row">
              <div class="col-lg-4 col-md-3">
                  <aside class="widget">
                      <div class="about-widget">
                          <!-- <a href="index.html"><img src="assets/images/logo.png" alt=""></a> -->
                          <p>
                              Say goodbye to the headaches of traditional project management and embrace a modern,
                              efficient
                              approach with our FYP management system.
                          </p>
                          <div class="ab-social">
                              <a class="fac" href="#"><i class="social_facebook"></i></a>
                              <a class="twi" href="#"><i class="social_twitter"></i></a>
                              <a class="you" href="#"><i class="social_youtube"></i></a>
                              <a class="lin" href="#"><i class="social_linkedin"></i></a>
                          </div>
                      </div>
                  </aside>
              </div>
              <div class="col-lg-3 col-md-3">
                  <aside class="widget">
                      <h3 class="widget-title">Explore</h3>
                      <ul>
                          <li><a href="about.php">About Us</a></li>
                      </ul>
                  </aside>
              </div>
              <div class="col-lg-3 col-md-3">
                  <aside class="widget">
                      <h3 class="widget-title">Manage</h3>
                      <ul>
                          <li><a href="#">Students</a></li>
                          <li><a href="#">Advisors</a></li>
                          <li><a href="#">Projects</a></li>
                          <li><a href="#">Groups</a></li>
                          <li><a href="#">Evaluations</a></li>
                      </ul>
                  </aside>
              </div>
          </div>
          <div class="row">
              <div class="col-lg-12 text-center">
                  <div class="copyright">
                      <p>© 2021 Copyright all Right Reserved Design by <a href="">Waqas</a>
                      </p>
                  </div>
              </div>
          </div>
      </div>
  </footer>
  <!-- Footer Section End -->

  <!-- Back To Top -->
  <a href="#" id="back-to-top">
      <i class="fal fa-angle-double-up"></i>
  </a>
  <!-- Back To Top -->

  <!-- Start Include All JS -->
  <script src="assets/js/jquery.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery.appear.js"></script>
  <script src="assets/js/owl.carousel.min.js"></script>
  <script src="assets/js/slick.js"></script>
  <script src="assets/js/jquery.nice-select.min.js"></script>
  <script src="assets/js/swiper-bundle.min.js"></script>
  <script src="assets/js/TweenMax.min.js"></script>
  <script src="assets/js/lightcase.js"></script>
  <script src="assets/js/jquery.plugin.min.js"></script>
  <script src="assets/js/jquery.countdown.min.js"></script>
  <script src="assets/js/jquery.easing.1.3.js"></script>
  <script src="assets/js/jquery.shuffle.min.js"></script>

  <script src="assets/js/theme.js"></script>
  <!-- End Include All JS -->

  </body>

  </html>