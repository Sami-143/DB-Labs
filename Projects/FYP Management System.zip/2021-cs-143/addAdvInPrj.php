<?php
include 'header.php'; 
include 'dbSQL.php';
?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Assign Advisor to Project</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Assign Advisor
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<section class="contact-section">
    <div class="container">
        <div class="row" style="margin: auto">
            <div class="col-md-8" style="margin: auto">
                <div class="contact-form" style="margin: auto">
                    <h4>Assign Advisor </h4>
                    <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                    <form action="projAction.php" method="post" class="row">
                        <div class="col-md-6">
                            <Label>Advisor Id</Label> <br>
                            <?php
                                $query =
                                    "SELECT Advisor.Id,Concat(FirstName, ' ', LastName) as advisorname FROM [Advisor] INNER JOIN PERSON ON Advisor.Id = PERSON.Id";
                                $res = db::getRecords($query);
                                $groupDropdown =
                                    '<select name="advId" required>';
                                foreach ($res as $grpRow) {
                                    $groupDropdown .=
                                        '<option value="' .
                                        $grpRow['Id'] .
                                        '">' .
                                        $grpRow['advisorname'] .
                                        '</option>';
                                }
                                $groupDropdown .= '</select>';
                                echo $groupDropdown;
                            ?>
                        </div>
                        <div class="col-md-6">
                            <Label>Project Id</Label> <br>
                            <?php
                                $query =
                                    "SELECT Id FROM [Project]";
                                $res = db::getRecords($query);
                                $groupDropdown =
                                    '<select name="projId" required>';
                                foreach ($res as $grpRow) {
                                    $groupDropdown .=
                                        '<option value="' .
                                        $grpRow['Id'] .
                                        '">' .
                                        $grpRow['Id'] .
                                        '</option>';
                                }
                                $groupDropdown .= '</select>';
                                echo $groupDropdown;
                            ?>
                        </div>
                        <div class="col-md-6 text-right" style="margin-top: 10px; margin-left: 60px">
                            <input type="submit" name="assignAdvSubmit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php';
?>