<?php
include 'header.php'; 
include 'dbSQL.php';
?>

        <!-- Banner Start -->
        <section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h2 class="banner-title">Contact Us</h2>
                        <div class="bread-crumbs">
                            <a href="index.html">Home</a> <span></span> Contact Us
                        </div>
                    </div>
                </div>
            </div>
        </section>  
        <!-- Banner End -->

        <!-- Contact Start -->
        <section class="contact-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="contact--info-area">
                            <h3>Get in touch</h3>
                            <p>
                                Looking for help? Fill the form and start a new adventure.
                            </p>
                            <div class="single-info">
                                <h5>Headquaters</h5>
                                <p>
                                    <i class="icon_house_alt"></i>
                                    744 New York Ave, Brooklyn, Kings,<br> New York 10224
                                </p>
                            </div>
                            <div class="single-info">
                                <h5>Phone</h5>
                                <p>
                                    <i class="icon_phone"></i>
                                    (+642) 245 356 432<br>
                                    (+420) 336 476 328
                                </p>
                            </div>
                            <div class="single-info">
                                <h5>Support</h5>
                                <p>
                                    <i class="icon_mail_alt"></i>
                                    bisy@support.com<br>
                                    help@education.com
                                </p>
                            </div>
                            <div class="ab-social">
                                <h5>Follow Us</h5>
                                <a class="fac" href="#"><i class="social_facebook"></i></a>
                                <a class="twi" href="#"><i class="social_twitter"></i></a>
                                <a class="you" href="#"><i class="social_youtube"></i></a>
                                <a class="lin" href="#"><i class="social_linkedin"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="contact-form">
                            <h4>Let’s Connect</h4>
                            <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p>
                            <form action="#" method="post" class="row">
                                <div class="col-md-6">
                                    <input type="text" name="f-name" placeholder="First Name">
                                </div>
                                <div class="col-md-6">
                                    <input type="text" name="l-name" placeholder="Last Name">
                                </div>
                                <div class="col-md-6">
                                    <input type="email" name="email" placeholder="Email Address">
                                </div>
                                <div class="col-md-6">
                                    <input type="number" name="phone" placeholder="Phone Number">
                                </div>
                                <div class="col-md-12">
                                    <input type="text" name="suject" placeholder="Subject">
                                </div>
                                <div class="col-md-12">
                                    <textarea name="message" placeholder="How can we help?"></textarea>
                                </div>
                                <div class="col-md-6">
                                    <div class="condition-check">
                                        <input id="terms-conditions" type="checkbox">
                                        <label for="terms-conditions">
                                            I agree to the <a href="#">Terms & Conditions</a>      
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6 text-right">
                                    <input type="submit" name="submit" value="Send Message">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Contact End -->

        <!-- Gamps Start -->
        <!-- <div class="bisylms-map">
            <iframe src="https://maps.google.com/maps?width=720&amp;height=600&amp;hl=en&amp;coord=39.966528,-75.158284&amp;q=1%20Grafton%20Street%2C%20Dublin%2C%20Ireland+(My%20Business%20Name)&amp;ie=UTF8&amp;t=p&amp;z=16&amp;iwloc=B&amp;output=embed"  ></iframe>
        </div> -->
        <!-- Gamps Start -->


<?php include 'footer.php';
?>
