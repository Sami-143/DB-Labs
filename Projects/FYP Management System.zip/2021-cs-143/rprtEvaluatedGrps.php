<?php
    include('header.php');
    include('dbSQL.php');
?>
<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Evaluated Groups</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Evaluated Groups
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->
<table class="container table table-light table-striped" style="margin-top:40px">
    <?php
        $query = "SELECT gs.GroupId as GroupId, gs.StudentId as StudentId, Person.FirstName as StudentName, gp.ProjectId as ProjectId, p.Title as Title, ev.Name as Evaluation, ev.TotalMarks as TotalMarks, ge.ObtainedMarks as ObtainedMarks from [Group] g INNER JOIN GroupStudent gs on  gs.GroupId = g.Id 
        INNER JOIN GroupProject gp on gp.GroupId = gs.GroupId INNER JOIN GroupEvaluation ge on ge.GroupId = gs.GroupId INNER JOIN Evaluation ev 
        on ev.Id = ge.EvaluationId INNER JOIN Project p on gp.ProjectId = p.Id INNER JOIN Student s on gs.StudentId = s.Id INNER JOIN Person on Person.Id = s.Id";

$res = db::getRecords($query);

$prevProjectId = null;
$prevStudentId = null;

echo '<table class="container table table-light table-striped" style="margin-top:40px">';
echo "<thead>";
echo "<tr>";
echo "<th>Group Id</th>";
echo "<th>Student Id</th>";
echo "<th>Student Name</th>";
echo "<th>Project Id</th>";
echo "<th>Project Title</th>";
echo "<th>Evaluation</th>";
echo "<th>Total Marks</th>";
echo "<th>Obtained Marks</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";

foreach ($res as $row) {
  if ($prevProjectId != $row['ProjectId'] || $prevStudentId != $row['StudentId']) {
      // start a new row for a new project and student
      echo "<tr>";
      echo "<td>" . $row['GroupId'] . "</td>";
      echo "<td>" . $row['StudentId'] . "</td>";
      echo "<td>" . $row['StudentName'] . "</td>";
      echo "<td>" . $row['ProjectId'] . "</td>";
      echo "<td>" . $row['Title'] . "</td>";
      echo "<td>" . $row['Evaluation'] . "</td>";
      echo "<td>" . $row['TotalMarks'] . "</td>";
      echo "<td>" . $row['ObtainedMarks'] . "</td>";
      echo "</tr>";
  } else {
      // continue adding evaluations in the same row
      echo "<td></td>";
      echo "<td></td>";
      echo "<td></td>";
      echo "<td></td>";
      echo "<td></td>";
      echo "<td>" . $row['Evaluation'] . "</td>";
      echo "<td>" . $row['ObtainedMarks'] . "</td>";
      echo "</tr>";
  }
  $prevProjectId = $row['ProjectId'];
  $prevStudentId = $row['StudentId'];
}

echo "</tbody>";
echo "</table>";

    ?>

</table>
<a href="javascript:window.print();" class="bisylms-btn" style="margin-left:800px; margin-bottom:100px">Print</a>

<?php
    // include('footer.php');
?>