<?php
include 'dbSQL.php';

if (isset($_POST['grpSubmit'])) {
    //get current date as created on date
    $createdOn = date('Y-m-d');
    $proId = $_POST['projId'];
    $assDate = $_POST['assDate'];
    if($assDate > $createdOn)
    {
        $sql = "INSERT INTO [Group] (Created_On) VALUES ('$createdOn')";
        $rowCount = db::insertRecords($sql);
        $sql = "INSERT INTO GroupProject (ProjectId, GroupId, AssignmentDate) 
        VALUES ('$proId', (SELECT MAX(Id) FROM [Group]), '$assDate')";
        $rowCount = db::insertRecords($sql);
    }
    else{
        echo '<script>alert("Assignment Date should be greater than Created On");</script>';
        return;
    }
    if ($rowCount > 0) {
        echo '<script>alert("Record inserted successfully.");</script>';
    } else {
        echo '<script>alert("Error in inserting");</script>';
    }
    return;
}
if (isset($_POST['grpDelSubmit'])) {
    $regNum = $_POST['regNum'];
    $fName = $_POST['f-name'];
    $sql = "SELECT Id FROM Student WHERE RegistrationNo = '$regNum'";
    $id = db::getRecords($sql);
    $sql = "DELETE FROM Student WHERE RegistrationNo = '$regNum'";
    $rowCount = db::deleteRecords($sql);
    $id = $id[0]['Id'];
    $sql = "DELETE FROM Person WHERE Person.Id = $id";
    $rowCount = db::deleteRecords($sql);
    if ($rowCount > 0) {
        echo '<script>alert("Record Deleted successfully.");</script>';
    } else {
        echo '<script>alert("Error in Deleting");</script>';
    }
    return;
}
if(isset($_POST['assignProjSubmit'])){
    $projId = $_POST['prjId']; 
    $grpId = $_POST['grpId']; 
    $assDate = date('Y-m-d');
    //not assign project to group if project is already assigned to group
    $query = "SELECT * FROM GroupProject WHERE GroupId = $grpId";
    $result = db::getRecords($query);
    if (count($result) > 0) {
        echo '<script>alert("Project is already assigned to this group.");</script>';
        return;
    }
    $query = "INSERT INTO GroupProject (ProjectId, GroupId, AssignmentDate) VALUES ('$projId', '$grpId', '$assDate')";
    $rowCount = db::insertRecords($query);
    if ($rowCount > 0) {
        echo '<script>alert("Record inserted successfully.");</script>';
    } else {
        echo '<script>alert("Error in inserting");</script>';
    }
    return;
}
if (isset($_POST['grpSearchSubmit'])) {
    $grpId = $_POST['grpId'];
    $query = "SELECT * FROM [Group] WHERE Id = $grpId";
    $result = db::getRecords($query);
    //get the count of students in the group
    $query = "SELECT COUNT(*) AS count FROM GroupStudent WHERE GroupId = $grpId";
    $count = db::getRecords($query);
    if ($count !== null && isset($count[0]['count'])) {
        $studentCount = $count[0]['count'];
    } else {
        $studentCount = 0;
    }
    // $sql = "SELECT Created_on from Student cross join [Group] Cross join GroupStudent where [Group].Id = GroupStudent.GroupId and GroupStudent.StudentId = $result[0]['Id']";
    // $result2 = db::getRecords($sql);
    if (count($result) > 0) { ?>
<!-- Banner Start -->
<?php include 'header.php'; ?>
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Search Group</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Search Group
                </div>
            </div>
        </div>
    </div>
</section>


<!-- Feature Course Start -->
<section class="feature-course-section">
    <div class="container">
        <div class="row shafull-container">
            <div class="col-lg-4 col-md-6 shaf-item">
                <div class="feature-course-item">
                    <div class="flipper">
                        <div class="front">
                            <div class="fcf-thumb">
                                <img src="assets/images/home/course/2.png" alt="">
                            </div>
                            <p><?php //echo $result2[0]['Created_on'] ?></p>
                            <h4><?php echo $result[0]['Id']; ?></h4>
                            <div class="fcf-bottom">
                                <!-- <a href="#"><i class="icon_profile"></i><?php echo count($count) ?></a> -->
                                <?php
                                    echo '<a href="#"><i class="icon_profile"></i>' . $studentCount . '</a>';
                                ?>
                            </div>
                        </div>
                        <div class="back">
                            <div class="fcf-thumb">
                                <img src="assets/images/home/course/2.png" alt="">
                            </div>
                            <!-- echo $result2[0]['Created_on']  -->
                            <!-- <a href="#" class="c-cate"></a> -->
                            <h4><a href="#">Id: <?php echo $result[0][
                                    'Id'
                                ] ?></a></h4>
                            <div class="ratings">
                                <span></span>
                            </div>
                            <div class="course-price">
                                Created On: <br>
                                <?php echo $result[0]['Created_On']; ?> </div>
                            <div class="author">
                                <img src="assets/images/home/course/author.png" alt="">
                                <a href="#"> </a>
                            </div>
                            <div class="fcf-bottom">
                                <?php
                                    echo '<a href="#"><i class="icon_profile"></i>' . $studentCount . '</a>';
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Feature Course End -->


<?php } else {echo '<script>alert("Record Not Found.");</script>';}
}
?>
<?php include 'footer.php'; ?>