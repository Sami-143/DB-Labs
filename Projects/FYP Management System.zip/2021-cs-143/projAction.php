<?php
include 'dbSQL.php';
if (isset($_POST['projSubmit'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $advisorId = $_POST['AdvisorId'];
    $advisorRole = $_POST['advisorRole'];
    $assignmentDate = $_POST['assDate'];
    //validations
    if (!preg_match("/^[a-zA-Z ]*$/", $title)) {
        echo '<script>alert("Project Title should contain only letters and white space.");</script>';
        return;
    }
    $sql = "SELECT * FROM Project WHERE Title = '$title'";
    $result = db::getRecords($sql);
    if (count($result) > 0) {
        echo '<script>alert("Project Title already exist.");</script>';
        return;
    } else {
        $sql = "INSERT INTO Project (Title, Description) 
        VALUES ('$title', '$description')";
        $rowCount = db::insertRecords($sql);
        $sql = "INSERT INTO ProjectAdvisor (AdvisorId, ProjectId, AdvisorRole, AssignmentDate) VALUES ('$advisorId', (SELECT MAX(Id) FROM Project), '$advisorRole', '$assignmentDate')";
        $rowCount = db::insertRecords($sql);
        if ($rowCount > 0) {
            echo '<script>alert("Record inserted successfully.");</script>';
        } else {
            echo '<script>alert("Error in inserting");</script>';
        }
    }
    return;
}
if (isset($_POST['projDelSubmit'])) {
    // $title = $_POST['title'];
    // $sql = "SELECT Project.Id FROM Project WHERE Title = '$title'";
    // $id = db::getRecords($sql);
    // $id = $id['Id'];
    // $sql = "DELETE FROM GroupProject WHERE GroupProject.ProjectId = $id";
    // db::deleteRecords($sql);
    // $sql = "DELETE FROM Project WHERE Title = '$title'";
    // $rowCount = db::deleteRecords($sql);
    // $sql = "DELETE FROM ProjectAdvisor WHERE ProjectAdvisor.ProjectId = $id";
    // $rowCount = db::deleteRecords($sql);
    // if ($rowCount > 0) {
    //     echo '<script>alert("Record Deleted successfully.");</script>';
    // } else {
    //     echo '<script>alert("Error in Deleting");</script>';
    // }
    // return;
}
if(isset($_POST['assignAdvSubmit'])){
    // $roleMapping = [
    //     'Advisor' => 11,
    //     'Co-Advisor' => 2,
    //     // add more mappings as needed
    // ];
    
    $advisorId = $_POST['advId'];
    $projectId = $_POST['projId'];
    
    $query = "SELECT * FROM ProjectAdvisor WHERE AdvisorId = '$advisorId' AND ProjectId = '$projectId'";
    $result = db::getRecords($query);
    if(count($result) > 0){
        echo '<script>alert("This Advisor already assigned to this project.");</script>';
        return;
    }
    //assign multiple advisors to a project
    //get current date
    $date = date('Y-m-d');
    $query = "SELECT AdvisorRole FROM ProjectAdvisor WHERE AdvisorId = '$advisorId'";
    $result = db::getRecords($query);
    $advisorRole = $result[0]['AdvisorRole'];

    $sql = "INSERT INTO ProjectAdvisor (AdvisorId, ProjectId, AdvisorRole, AssignmentDate) VALUES ('$advisorId', '$projectId', '$advisorRole', '$date')";
    $rowCount = db::insertRecords($sql);
    if ($rowCount > 0) {
        echo '<script>alert("Record inserted successfully.");</script>';
    } else {
        echo '<script>alert("Error in inserting");</script>';
    }
    return;
}
if (isset($_POST['projSearchSubmit'])) {
    $title = $_POST['title'];
    $sql = "SELECT * FROM Project WHERE Title = '$title'";
    $result = db::getRecords($sql);
    if (count($result) > 0) { ?>
<!-- Banner Start -->
<?php include 'header.php'; ?>
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Project Data</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Project Data
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->
<!-- Feature Course Start -->
<section class="feature-course-section">
    <div class="container">
        <div class="row shafull-container">
            <div class="col-lg-4 col-md-6 shaf-item">
                <div class="feature-course-item">
                    <div class="flipper">
                        <div class="front">
                            <div class="fcf-thumb">
                                <img src="assets/images/home/course/2.png" alt="">
                            </div>
                            <p><?php //echo $result2[0]['Created_on'] ?></p>
                            <h4><?php echo $result[0]['Title']; ?></h4>
                            <div class="fcf-bottom">
                                <?php
                                $sql3 = "SELECT 
                                p.Id AS ProjectId,
                                p.Title AS ProjectTitle,
                                g.Id AS GroupId,
                                COUNT(gs.StudentId) AS NumStudents
                                FROM Project p
                                INNER JOIN GroupProject gp ON p.Id = gp.ProjectId
                                INNER JOIN [Group] g ON g.Id = gp.GroupId
                                INNER JOIN GroupStudent gs ON gs.GroupId = g.Id
                                GROUP BY p.Id, p.Title, g.Id";
                                $result3 = db::getRecords($sql3);
                                $NumStudents = $result3[0]['NumStudents'];
                                echo '<a href="#"><i class="icon_profile"></i>'. $NumStudents . '</a> ';
                            ?>
                            </div>
                        </div>
                        <div class="back">
                            <div class="fcf-thumb">
                                <img src="assets/images/home/course/2.png" alt="">
                            </div>
                            <!-- echo $result2[0]['Created_on']  -->
                            <!-- <a href="#" class="c-cate"></a> -->
                            <h4><a href="#"><?php echo $result[0][
                                    'Title'
                                ] ?></a></h4>
                            <div class="ratings">
                                <span></span>
                            </div>
                            <div class="course-price" style="font-size: 15px"> Description:
                                <?php echo $result[0]['Description']; ?>
                            </div>
                            <div class="author">
                                <img src="assets/images/home/course/author.png" alt="">
                                <a href="#"> </a>

                            </div>
                            <div class="fcf-bottom">
                                <?php
                                $sql3 = "SELECT 
                                p.Id AS ProjectId,
                                p.Title AS ProjectTitle,
                                g.Id AS GroupId,
                                COUNT(gs.StudentId) AS NumStudents
                                FROM Project p
                                INNER JOIN GroupProject gp ON p.Id = gp.ProjectId
                                INNER JOIN [Group] g ON g.Id = gp.GroupId
                                INNER JOIN GroupStudent gs ON gs.GroupId = g.Id
                                GROUP BY p.Id, p.Title, g.Id";
                                $result3 = db::getRecords($sql3);
                                $NumStudents = $result3[0]['NumStudents'];
                                echo '<a href="#"><i class="icon_profile"></i>'. $NumStudents . '</a> ';
                            ?>
                                <!-- <a href="#"><i class="icon_profile"></i> </a> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Feature Course End -->

<?php } else {
    echo '<script>alert("Record Not Found. ");</script>' ;}
}
?>
<?php include 'footer.php'; ?>