<?php
include 'header.php'; ?>
<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">About Us</h2>
                <div class="bread-crumbs">
                    <a href="index.html">Home</a> <span></span> About Us
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<!-- About Start -->
<section class="abpage-section-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="ab-thumb">
                    <img src="assets/images/home2/1.png" alt="">
                </div>
            </div>
            <div class="col-lg-5">
                <div class="ab-content-2">
                    <h3>What will you Get?</h3>
                    <p>
                        The FYP (Final Year Project) Management System is an application designed to assist academic
                        institutions in managing the process of final year project submissions. It provides a
                        user-friendly interface that simplifies the tasks of managing students, advisors, project
                        groups, evaluations, and other related tasks. The system helps to ensure that all project
                        submissions are well-organized and the data is accurately maintained.
                    </p>
                    <!-- <a class="read-more" href="#">Browse Classes<i class="arrow_right"></i></a> -->
                </div>
                <div class="fact-wrapper">
                    <div class="funfact-item text-center">
                        <img src="assets/images/home2/f1.png" alt="">
                        <h2><span data-counter="242" class="timer">242</span>+</h2>
                        <p>Students</p>
                    </div>
                    <div class="funfact-item text-center">
                        <img src="assets/images/home2/f2.png" alt="">
                        <h2><span data-counter="62" class="timer">62</span>+</h2>
                        <p>Projects</p>
                    </div>
                    <div class="funfact-item text-center">
                        <img src="assets/images/home2/f3.png" alt="">
                        <h2><span data-counter="50" class="timer">50</span>+</h2>
                        <p>Award</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- About End -->

<?php include 'footer.php';
?>