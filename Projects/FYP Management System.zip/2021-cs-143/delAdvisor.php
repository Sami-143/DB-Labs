<?php
include 'header.php';
include 'dbSQL.php';
 ?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Delete Advisor</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Delete Advisor
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<section class="contact-section">
    <div class="container">
        <div class="row" style="margin: auto">
            <div class="col-md-8" style="margin: auto">
                <div class="contact-form" style="margin: auto">
                    <h4>Delete Advisor </h4>
                    <!-- <p>Integer at lorem eget diam facilisis lacinia ac id massa.</p> -->
                    <form action="advAction.php" method="post" class="row">
                        <div class="col-md-6">
                            <Label>Name</Label> <br>
                            <?php
                                $query = 'SELECT FirstName as advisorname FROM Person Inner Join Advisor on Person.Id = Advisor.Id';
                                $res = db::getRecords($query);
                                $GroupDropdown =
                                    '<select name="f-name" required>';

                                foreach ($res as $grpRow) {
                                    $GroupDropdown .=
                                        '<option value="' .
                                        $grpRow['advisorname'] .
                                        '">' .
                                        $grpRow['advisorname'] .
                                        '</option>';
                                }
                                $GroupDropdown .= '</select>';
                                echo $GroupDropdown;
                            ?>
                        </div>
                        <div class="col-md-6">
                            <Label>Designation</Label> <br>
                            <?php
                                $query =
                                    "SELECT * FROM Lookup where Category = 'Designation'";
                                $res = db::getRecords($query);
                                $designationDropdown =
                                    '<select name="designation">';

                                foreach ($res as $des) {
                                    $designationDropdown .=
                                        '<option value="' .
                                        $des['Id'] .
                                        '">' .
                                        $des['Value'] .
                                        '</option>';
                                }
                                $designationDropdown .= '</select>';
                                echo $designationDropdown;
                                ?>
                        </div>
                        <div class="col-md-6 text-right" style="margin-left: 70px">
                            <input type="submit" name="advDelSubmit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>