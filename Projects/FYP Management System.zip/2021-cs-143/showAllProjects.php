<?php
include 'header.php';
include 'dbSQL.php';
 ?>

<!-- Banner Start -->
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Projects</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Projects
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->

<!-- Feature Course Start -->
<section class="feature-course-section">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <h2 class="sec-title">Projects</h2>
            </div>
        </div>
        <div class="row shafull-container">
            <?php 
            // Array of banner images
                $banners = array(
                    '1.png',
                    '2.png',
                    '3.png'
                );
                
                $sql = "SELECT * FROM Project";
                $result = db::getRecords($sql);
                //get project details from projectadvisor table 
                $sql2 = "SELECT * FROM ProjectAdvisor";
                $result2 = db::getRecords($sql2);
               
                foreach($result as $temp)
                {
                    // Randomly select a banner from the array
                    $advisorName = " ";
                    $banner = $banners[array_rand($banners)];
                    
                    $sql3 = "SELECT 
                            p.Id AS ProjectId,
                            p.Title AS ProjectTitle,
                            g.Id AS GroupId,
                            COUNT(gs.StudentId) AS NumStudents
                            FROM Project p
                            INNER JOIN GroupProject gp ON p.Id = gp.ProjectId
                            INNER JOIN [Group] g ON g.Id = gp.GroupId
                            INNER JOIN GroupStudent gs ON gs.GroupId = g.Id
                            GROUP BY p.Id, p.Title, g.Id";
                    $result3 = db::getRecords($sql3);
                     // set initial value of NumStudents to 0
                    $query = "SELECT ProjectId, AssignmentDate FROM GroupProject INNER JOIN Project ON Project.Id = GroupProject.ProjectId";
                    $result4 = db::getRecords($query);
                    $NumStudents = 0;
                    foreach($result3 as $temp2) {
                        // check if the current project matches the project from the inner loop
                        if($temp['Id'] == $temp2['ProjectId']) {
                            $NumStudents = $temp2['NumStudents'];
                            break;
                        }
                    }  
                    $assignmentDate = " ";
                    foreach($result4 as $temp3) {
                        // check if the current project matches the project from the inner loop
                        if($temp['Id'] == $temp3['ProjectId']) {
                            $assignmentDate = date('Y-m-d', strtotime($temp3['AssignmentDate']));
                            break;
                        }
                    }
                    $section = ' <div class="col-lg-4 col-md-6 shaf-item"> ';   
                    $section .= '    <div class="feature-course-item">';
                    $section .= '                     <div class="flipper"> ';
                    $section .= '         <div class="front"> ';
                    $section .= '             <div class="fcf-thumb"> ';
                    $section .= '                 <img src="assets/images/home/course/' . $banner . '" alt=""> ';
                    $section .= '             </div> ';
                    $section .= '               <h4>' . (isset($temp['Title']) ? $temp['Title'] : '') . '</h4>';
                    $section .= '             <div class="fcf-bottom"> ';
                    $section .= '                 <a href="#"><i class="icon_profile"></i>'. $NumStudents . '</a> ';
                    $section .= '             </div> ';
                    $section .= '         </div> ';
                    $section .= '         <div class="back"> ';
                    $section .= '             <div class="fcf-thumb"> ';
                    $section .= '                 <img src="assets/images/home/course/' . $banner . '" alt=""> ';
                    $section .= '             </div> ';
                    $section .= '             <h4><a href="#">' . (isset($temp['Title']) ? $temp['Title'] : '') . '</a></h4> ';
                    $section .= '             <div class="course-price" style = "font-size: 15px"> ';
                    $section .= '                 ' . "Description: " . (isset( $temp['Description']) ?  $temp['Description'] : '') . ' ';
                    $section .= '             </div> ';
                    $section .= '             <div class="course-price" style = "font-size: 15px"> ';
                    $query2 = "SELECT FirstName, Project.Id FROM Project INNER JOIN ProjectAdvisor ON $temp[Id] = ProjectAdvisor.ProjectId INNER JOIN Advisor ON Advisor.Id = ProjectAdvisor.AdvisorId INNER JOIN Person ON Person.Id = Advisor.Id";
                    $result5 = db::getRecords($query2);
                    if ($result5 !== null) {
                      foreach ($result5 as $row) {
                        if($temp['Id'] == $row['Id']) {
                            $advisorName = $row['FirstName'];
                            $section .= '                 ' . "Advisors: " . (isset($advisorName) ?  $advisorName : '') . ' ';
                          }
                        }
                    } else {
                    }
                    $section .= '             </div> ';
                    $section .= '             <div class="fcf-bottom"> ';
                    $section .= '                 <a href="lesson.php?ProjectId=' . $assignmentDate . '"><i class=""></i>' . $assignmentDate . '</a> ';
                    $section .= '                 <a href="#"><i class="icon_profile"></i>'. $NumStudents . '</a> ';
                    $section .= '             </div> ';
                    $section .= '         </div> ';
                    $section .= '     </div> ';
                    $section .= ' </div> ';
                    $section .= ' </div> ';
                    echo $section;
                }
            ?>
        </div>
    </div>
</section>
<!-- Feature Course End -->


<?php include 'footer.php'; ?>