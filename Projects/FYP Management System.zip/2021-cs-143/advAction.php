<?php
include 'dbSQL.php';
if (isset($_POST['advSubmit'])) {
    $fName = $_POST['f-name'];
    $lName = $_POST['l-name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $designation = $_POST['designation'];
    $salary = $_POST['salary'];
    //validations
    if (!preg_match("/^[a-zA-Z ]*$/", $fName)) {
        echo '<script>alert("First Name should contain only letters and white space.");</script>';
        return;
    }
    if (!preg_match("/^[a-zA-Z ]*$/", $lName)) {
        echo '<script>alert("Last Name should contain only letters and white space.");</script>';
        return;
    }
    if (!preg_match("/^[0-9]*$/", $phone)) {
        echo '<script>alert("Phone Number should contain only numbers.");</script>';
        return;
    } 
    $dob = date('Y-m-d', strtotime($dob));
    $today = date("Y-m-d");
    if ($dob > $today) {
        echo '<script>alert("Date of Birth should be less than current date.");</script>';
        return;
    }
    
    $sql = "SELECT Person.Id FROM Person WHERE email = '$email'";
    $result = db::getRecords($sql);
    if (count($result) > 0) {
        echo '<script>alert("Advisor already exist.");</script>';
        return;
    } else {
        if($salary < 0){
            echo '<script>alert("Salary should be greater than 0");</script>';
            return;
        }
        $sql = "INSERT INTO Person (FirstName, LastName, Contact, Email, DateofBirth, Gender) 
        VALUES ('$fName', '$lName', '$phone', '$email', '$dob', '$gender')";
        $rowCount = db::insertRecords($sql);
        $sql = "INSERT INTO Advisor (Id, Designation, Salary) VALUES ((SELECT MAX(Id) FROM Person), '$designation', '$salary')";
        $rowCount = db::insertRecords($sql);
        if ($rowCount > 0) {
            echo '<script>alert("Record inserted successfully.");</script>';
        } else {
            echo '<script>alert("Error in inserting");</script>';
        }
    }
    return;
}
if (isset($_POST['advDelSubmit'])) {
    $fName = $_POST['f-name'];
    $designation = $_POST['designation'];

    $sql = "SELECT Person.Id FROM Advisor Cross Join Person WHERE Advisor.Id = Person.Id and FirstName = '$fName' and Designation = '$designation'";
    $id = db::getRecords($sql);
    if (count($id) == 0) {
    echo '<script>alert("Advisor does not exist.");</script>';
    return;
    }
    $id = $id[0]['Id'];

    // delete corresponding records from the ProjectAdvisor table first
    $sql = "DELETE FROM ProjectAdvisor WHERE AdvisorId = $id";
    $rowCount = db::deleteRecords($sql);

    // delete record from the Advisor table
    $sql = "DELETE FROM Advisor WHERE Advisor.Id = $id";
    $rowCount = db::deleteRecords($sql);

    // delete record from the Person table
    $sql = "DELETE FROM Person WHERE Person.Id = $id";
    $rowCount = db::deleteRecords($sql);

    if ($rowCount > 0) {
        echo '<script>alert("Record Deleted successfully.");</script>';
    } else {
        echo '<script>alert("Error in Deleting");</script>';
    }
    return;
}
if(isset($_POST['advUpdSubmit']))
{
    //get the values from the form
    $fName = $_POST['f-name'];
    $lName = $_POST['l-name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];
    
    $advId = $_POST['advId'];
    $designation = $_POST['designation'];
    $salary = $_POST['salary'];
    
    
    //validations
    if (!preg_match("/^[a-zA-Z ]*$/", $fName)) {
        echo '<script>alert("First Name should contain only letters and white space.");</script>';
        return;
    }
    if (!preg_match("/^[a-zA-Z ]*$/", $lName)) {
        echo '<script>alert("Last Name should contain only letters and white space.");</script>';
        return;
    }
    if (!preg_match("/^[0-9]*$/", $phone)) {
        echo '<script>alert("Phone Number should contain only numbers.");</script>';
        return;
    }
    if($salary < 0){
        echo '<script>alert("Salary should be greater than 0");</script>';
        return;
    }
    $dob = date('Y-m-d', strtotime($dob));
    $today = date("Y-m-d");
    if ($dob > $today) {
        echo '<script>alert("Date of Birth should be less than current date.");</script>';
        return;
    }
    $sql = "SELECT Person.Id FROM Person WHERE email = '$email'";
    $result = db::getRecords($sql);
    
    //now update the records 
    $sql = "UPDATE Person SET FirstName = '$fName', LastName = '$lName', Contact = '$phone', Email = '$email', DateofBirth = '$dob' WHERE Id = $advId";
    $rowCount = db::updateRecords($sql);
    
    //update salary and designation in Advisor table
    $sql = "UPDATE Advisor SET Designation = '$designation', Salary = $salary WHERE Id = $advId";
    $rowCount = db::updateRecords($sql);
    
    if ($rowCount > 0) {
        echo '<script>alert("Record updated successfully.");</script>';
    } else {
        echo '<script>alert("Error in updating");</script>';
    }
    return;
    
            
}
if (isset($_POST['advSearchSubmit'])) {
    $id = $_POST['Id'];
    $sql = "SELECT * FROM Person Inner Join Advisor on Advisor.Id = Person.Id WHERE Person.Id = $id";
    $result = db::getRecords($sql); 
    if (count($result) > 0) { ?>
<!-- Banner Start -->
<?php include 'header.php'; ?>
<section class="page-banner" style="background-image: url(assets/images/banner.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="banner-title">Advisor Data</h2>
                <div class="bread-crumbs">
                    <a href="index.php">Home</a> <span></span> Advisor Data
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Banner End -->
<!-- Feature Course Start -->
<section class="feature-course-section">
    <div class="container">
        <div class="row shafull-container">
            <div class="col-lg-4 col-md-6 shaf-item">
                <div class="feature-course-item">
                    <div class="flipper">
                        <div class="front">
                            <div class="fcf-thumb">
                                <img src="assets/images/home/course/2.png" alt="">
                            </div>
                            <p><?php //echo $result2[0]['Created_on'] ?></p>
                            <h4><?php echo $result[0]['FirstName']; ?></h4>
                            <div class="fcf-bottom">
                                <?php   if ($result[0]['Gender'] == 1) {
                                            $temp = 'Male';
                                        } else {
                                            $temp = 'Female';
                                        }
                                ?>
                                <a href="#"><i class="icon_profile"></i><?php echo $temp; ?></a>
                            </div>
                        </div>
                        <div class="back">
                            <div class="fcf-thumb">
                                <img src="assets/images/home/course/2.png" alt="">
                            </div>
                            <!-- echo $result2[0]['Created_on']  -->
                            <!-- <a href="#" class="c-cate"></a> -->
                            <h4><a href="#"><?php echo $result[0][
                                    'FirstName'
                                ] . 
                                    ' ' .
                                    $result[0]['LastName']; ?></a></h4>
                            <div class="ratings">
                                <span><?php echo $result[0][
                                        'Email'
                                    ]; ?></span>
                            </div>
                            <div class="course-price">
                                <?php echo $result[0]['Contact']; ?>
                            </div>
                            <div class="author">
                                <img src="assets/images/home/course/author.png" alt="">
                                <a href="#"> </a>
                            </div>
                            <div class="fcf-bottom">
                                <a href="#"><i class="icon_profile"></i><?php echo $temp; ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Feature Course End -->

<?php } else {
    echo '<script>alert("Record Not Found. ");</script>' ;}
}
?>
<?php include 'footer.php'; ?>