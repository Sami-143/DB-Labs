<!DOCTYPE html>
<html lang="en">


<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

<head>
    <title>Bisylms - Education HTML5 Responsive Template</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">

    <!-- Start Include All CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.css" />
    <link rel="stylesheet" href="assets/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/elegant-icons.css" />
    <link rel="stylesheet" href="assets/css/themify-icons.css" />
    <link rel="stylesheet" href="assets/css/animate.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/slick.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/lightcase.css">
    <link rel="stylesheet" href="assets/css/preset.css" />
    <link rel="stylesheet" href="assets/css/theme.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
    <!-- End Include All CSS -->

    <!-- Favicon Icon -->
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
    <!-- Favicon Icon -->
</head>

<body>
    <!-- connect with database -->
    <!-- connect with database -->

    <!-- Preloader Icon -->
    <!-- <div class="preloader">
        <div class="loaderInner">
            <div id="top" class="mask">
                <div class="plane"></div>
            </div>
            <div id="middle" class="mask">
                <div class="plane"></div>
            </div>
            <div id="bottom" class="mask">
                <div class="plane"></div>
            </div>
            <p>LOADING...</p>
        </div>
    </div> -->
    <!-- Preloader Icon -->

    <!-- Header Start -->
    <header class="header-01 sticky">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg">
                        <!-- logo Start-->
                        <a class="navbar-brand" href="index.html">
                            <!-- <img src="assets/images/logo.png" alt=""> -->
                            <!-- <img class="sticky-logo" src="assets/images/logo4.png" alt=""> -->
                        </a>
                        <!-- logo End-->

                        <!-- Moblie Btn Start -->
                        <button class="navbar-toggler" type="button">
                            <i class="fal fa-bars"></i>
                        </button>
                        <!-- Moblie Btn End -->

                        <!-- Nav Menu Start -->
                        <div class="collapse navbar-collapse">
                            <ul class="navbar-nav">
                                <li class="menu-item-has-children">
                                    <a href="index.php">Home</a>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0);">Manage</a>
                                    <ul class="sub-menu">
                                        <li class="menu-item-has-children">
                                            <a href="javascript:void(0);">Manage Students</a>
                                            <ul class="sub-menu">
                                                <li><a href="addStudent.php">Add Student</a></li>
                                                <!-- <li><a href="delStudent.php">Delete Student</a></li> -->
                                                <li><a href="updateStudent.php">Update Student</a></li>
                                                <li><a href="searchStudent.php">Search Student</a></li>
                                                <li><a href="showStudents.php">Show All Students</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item-has-children">
                                            <a href="javascript:void(0);">Manage Advisor</a>
                                            <ul class="sub-menu">
                                                <li><a href="addAdvisor.php">Add Advisor</a></li>
                                                <!-- <li><a href="delAdvisor.php">Delete Advisor</a></li> -->
                                                <li><a href="updateAdvisor.php">Update Advisor</a></li>
                                                <li><a href="searchAdvisor.php">Search Advisor</a></li>
                                                <li><a href="allAdvisors.php">Show All Advisors</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item-has-children">
                                            <a href="javascript:void(0);">Manage Project</a>
                                            <ul class="sub-menu">
                                                <li><a href="addProject.php">Add Project</a></li>
                                                <!-- <li><a href="delProject.php">Delete Project</a></li> -->
                                                <li><a href="searchProject.php">Search Project</a></li>
                                                <li><a href="showAllProjects.php">Show All Project</a></li>
                                                <li><a href="addAdvInPrj.php">Add Advisor in Project</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item-has-children">
                                            <a href="javascript:void(0);">Manage Group</a>
                                            <ul class="sub-menu">
                                                <li><a href="addGroup.php">Add Group</a></li>
                                                <!-- <li><a href="delGroup.php">Delete Group</a></li> -->
                                                <li><a href="searchGroup.php">Search Group</a></li>
                                                <li><a href="allGroups.php">All Groups</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item-has-children">
                                            <a href="javascript:void(0);">Manage Evaluation</a>
                                            <ul class="sub-menu">
                                                <li><a href="addEvaluation.php">Add Evaluation</a></li>
                                                <!-- <li><a href="delEvaluation.php">Delete Evaluation</a></li> -->
                                                <li><a href="searchEvaluation.php">Search Evaluation</a></li>
                                                <li><a href="allEvaluations.php">All Evaluations</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item-has-children">
                                            <a href="javascript:void(0);">Generate Reports</a>
                                            <ul class="sub-menu">
                                                <li><a href="rprtStudent.php">Student Report</a></li>
                                                <li><a href="rprtSdtNotInGrp.php">Students(Not assigned any group)</a>
                                                <li><a href="rprtGrpStd.php">Students Groups</a>
                                                <li><a href="rprtPrjWithAdv.php">Info of Projects</a>
                                                <li><a href="rprtPrjNotAss.php">Project(Not assigned)</a>
                                                <li><a href="rprtEvaluatedGrps.php">Evaluated Groups</a>
                                                <li><a href="rprtTop10Grps.php">Top 10 Groups</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a href="404.html">404 Page</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="javascript:void(0);">Function on Group</a>
                                    <ul class="sub-menu">
                                        <li><a href="addGrpStudent.php">Add Student</a></li>
                                        <!-- <li><a href="delGrpStudent.php">Delete Student</a></li> -->
                                        <!-- <li><a href="searchGrpStudent.php">Search Student</a></li> -->
                                        <li><a href="assignPrjToGrp.php">Assign Project</a></li>
                                        <li><a href="evaluateGroup.php">Evaluate Group</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="about.php">About</a>
                                </li>
                                <li>
                                    <!-- <a href="contact.php">Contact</a> -->
                                </li>
                            </ul>
                        </div>
                        <!-- Nav Menu End -->

                        <!-- User Btn -->
                        <a href="#" class="user-btn"><i class="ti-user"></i></a>
                        <!-- User Btn -->

                        <!-- Join Btn -->
                        <!-- <a href="#" class="join-btn">Join for Free</a> -->
                        <!-- Join Btn -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Header End -->